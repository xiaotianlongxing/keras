# 粘连细胞核风险感知局部纠错 Implementation Plan

**Goal:** 让 WorkBuddy＋Kimi K3 在独立研究目录实现、执行并审计一套 16GB 显存内的细胞核选择性纠错实验，最终生成有证据来源的论文初稿。

**Architecture:** `nrr` Python CLI 负责数据谱系、分组封存、评价器、模型训练、候选构造、风险筛选与隔离评价。所有模块通过版本化 JSON/实例 PNG 通信；`infer` 不接收真值路径，`evaluate` 只在策略冻结后读取封存标签。任务状态、配置和文件哈希持久化，以便 WorkBuddy 会话恢复。

**Tech Stack:** Python 3.10+、与 RTX 5060 Ti 驱动兼容的 CUDA PyTorch、NumPy、scikit-image、SciPy、scikit-learn、pytest、JSON Schema 校验器；Kimi K3 仅负责代码与论文协作，实际指标由脚本计算。具体版本以环境预检的可安装且可运行版本锁定。

---

本计划的**执行目录**是用户机器上的 `<PROJECT>`，不是本交付文档目录。若在当前应用仓库工作，使用 `research/nuclei-risk-repair/`。下面的路径均相对该执行目录。本文件是交给 WorkBuddy 的明确任务契约；用户当前收到的是文档包，`nrr` 代码尚未生成。

## 文件职责与对外接口

| 文件 | 单一职责 | 必须输出/测试 |
| --- | --- | --- |
| `nrr/__main__.py` | 解析 `preflight/doctor/data/metrics/train/candidates/oracle/calibrate/infer/evaluate/freeze/paper` 子命令 | `python -m nrr --help` 列出全部命令 |
| `nrr/protocol.py` | 加载与校验 `protocol.json`，计算配置哈希 | 配置缺字段或越界明确失败 |
| `nrr/state.py` | 原子写状态、哈希审计、GPU 单进程锁 | 中断后不重复已验证任务 |
| `nrr/data.py` | 官方下载、SHA-256、元数据、组键、重复检查 | `data/source_manifest.json` |
| `nrr/seal.py` | 实验组划分、路径访问审计及封存 | `data/splits.json`、`data/seal.json` |
| `nrr/metrics.py` | PQ、AJI、计数和局部配对损失的同版实现 | 手算数组及参考库样例一致 |
| `nrr/model.py` | 四层 U-Net 与预测掩膜解码 | 256×256 前向输出尺寸正确 |
| `nrr/train.py` | OOF、最终基线、验证器训练与计时 | `time_budget.json` 包含全部阶段 |
| `nrr/candidates.py` | 局部峰、分水岭候选、实例标签稳定化 | 候选并集等于原始父实例 |
| `nrr/verifier.py` | RGB 像素关系证据、几何版负对照与轻度变换重算 | 不导入真值路径到推理模块；几何版留 OOF/部署权重 |
| `nrr/risk.py` | `p_harm/g` 学习、D_dev 校准、固定策略排序 | 概率范围与训练谱系记录 |
| `nrr/innovation.py` | 每图预计伤害预算、伪切界负对照、留出像素反事实证据 | 同覆盖率对照及 C 的开发集增量门槛 |
| `nrr/inference.py` | C1/C2 判定、拒绝回退、逐候选证据、合法候选分区和独立运行错误记录 | 原/修正掩膜、`evidence.jsonl`、`candidate_manifest.jsonl`、`candidate_proposals/`、`runtime_errors.jsonl`、`score_shuffle_manifest.jsonl` 与 `mechanism_scores.jsonl` |
| `nrr/evaluator.py` | 只读已冻结预测/候选分区、机制分数与封存真值，算各数据集和种子结果；不得重新推理或提名 | 每图 JSON、H3 候选关联与汇总表 |
| `nrr/statistics.py` | 原图/来源组汇总、区间、可选 CP 审核 | 组数不足返回 `C3_NOT_ESTABLISHED` |
| `nrr/paper.py` | 从已审计结果生成表图数据与 claim ledger | `paper/manuscript.md` 无无源数字 |
| `tests/` | 封存隔离、数学指标、风险门槛、回退与恢复的反例测试 | `pytest -q` 全部通过 |

文件可根据 WorkBuddy 所在平台做等价调整，但 CLI、数据字段和输出契约必须保持稳定；变更需写 `implementation_deviations.md`。

## 任务顺序和验收命令

### Task 1：建立可恢复研究项目

创建上述目录、`nrr/__main__.py`、`nrr/protocol.py` 与 `nrr/state.py`，将本包原样复制到执行目录。实现 `python -m nrr preflight --protocol protocol.json --output runs/preflight.json`。通过标准：能实测 GPU 前/反向；`state.json` 在异常退出后依然是合法 JSON；重复启动不会删除已完成任务。验证：`python -m nrr preflight ...` 和 `pytest tests/test_state.py -q`；失败时只写 `BLOCKED_CAPABILITY`，不得进入下载。

### Task 2：下载、审计、封存数据

实现 `data fetch/audit/split/seal` 四个子命令，先保存官方来源和校验和，再检查近重复，最后按最高可核查来源组分 `D_fit/D_dev/D_cal`。写测试：同一原图裁块在不同 split 必须失败；训练入口传外测掩膜路径必须失败；近重复跨源未处理必须阻断 `data seal`。验证：`pytest tests/test_data_seal.py -q`、`python -m nrr data audit ...`。若当前站点无法下载，允许继续写代码和评价器，状态保持 `DATA_BLOCKED`。

### Task 3：先完成数学指标

实现 `nrr/metrics.py`，对以下小例子写测试：两个真值核被预测成一个时错误合并增加；一个真值核被拆两块时错误拆分增加；预测 ID 跳号不改变 PQ/AJI；空前景的风险分母为 null；有真值但 `N_pos<2` 时 `dL=null`、`dL_utility=0`，真值缺失则标 `DATA_INVALID`。`harm` 必须符合 `04-statistics.md` 的三个条件。20 图可视化审计命令只能接收 `--split data/fit_split.json`，传 `D_cal` 或外测清单必须拒绝。Kimi 同步生成 `reports/novelty_precheck.md`，列出近邻全文/摘要级别和动作风险对照矩阵。验证：`pytest tests/test_metrics.py tests/test_leakage.py -q`、20 张 `D_fit` 图审计及先期文献核查。核心指标失败时任何训练结果无效。

### Task 4：生成轻量基线与真正 OOF 错误样本

实现轻量 U-Net 与 marker watershed，先一张图过拟合以排查标签与反向传播，再按 2 折组划分训练并输出留出预测，最后训练部署权重。写测试：OOF 表中每图的预测权重训练组列表不含本图组；运行限时器覆盖三个训练阶段。验证：`pytest tests/test_oof.py -q`，再运行 `python -m nrr train baseline-oof ...`。若墙钟预算预测失败，产生新版配置并缩模重测，不能悄悄截断日志。

### Task 5：构造分裂候选并验证不变量

实现三个尺度候选、稳定 ID 分配与 C1 检查。写反例测试：背景被改、父外像素被改、子块数为 1 或 4、子块不连通、子块并集少一像素、新 ID 与原图其他实例或已编辑父实例冲突、超面积预算，都应拒绝且输出严格等于 `M0`。先生成 `fit_candidates_base/`、`dev_candidates_base/` 和 `candidate_invariants_base.json`；开发隔离评价器只输出三种预定可行 oracle 的完整结果，以及仅含全局布尔 `enable_dual_source` 的 `d_trigger.json`。按该布尔值用同一选定候选器重建 `fit_candidates/`、`dev_candidates/`，再做最终 C1 和 `reports/oracle_dev.json`。最终三种固定诊断至少一种须 `ΔPQ>0.005` 或 `ΔCountMAE<0`，否则停止有效纠错路线。验证：`pytest tests/test_candidates.py tests/test_invariants.py -q` 及 T07/T08 全部路径与哈希齐全。

### Task 6：训练独立图像验证器与风险模型

实现 RGB/几何像素对、未校准的同核分数、真实 OOF 候选分数，并在同一配对监督上另存同架构去 RGB 几何版 MLP 的两折 OOF 分数与部署权重；风险特征及 `p_harm/g` 只用主验证器。T10 先用独立真值评价进程的 `metrics label-fit` 生成 `fit_candidate_labels.jsonl` 与 `reports/label_audit.json`，逐项核对图像/来源组、候选哈希、OOF 权重与评价器哈希；风险训练只按图像 ID＋候选哈希读取标签，不再打开真值。推理 `risk.py` 只接受候选与特征数组。再实现 A 每图预计伤害预算、B 切界负对照和 CPU 版 C 留出像素证据；B 的伪切界种子、构造和层内打乱规则在**首次 T11 计算前**与协议一同固定；A/C 的所有门槛计入 24 项开发搜索，C 未过增量门槛不得入主策略。写测试：打乱真值 ID 而保留实例分组，监督标签不变；把 `actual_harm` 注入推理证据必须违反 schema；风险概率都落在 `[0,1]`；风险预算等于 0 时不得接受编辑；伪切界不修改输出掩膜。验证：`pytest tests/test_risk.py tests/test_leakage.py tests/test_innovation.py -q`、标签审计零冲突、`reports/innovation_dev.json`、`reports/negative_controls_dev.json`。

### Task 7：选择、冻结并回退

实现 `D_dev` 预注册最多 24 个策略组合，依据 `03-agent-handbook.md` 的排序选择。固定切界与原模型置信度对照各自最多评估 24 个 `D_fit` OOF 分位点，按 `04-statistics.md` 的候选级公式及来源组覆盖率匹配规则选阈值；`ALL_CANDIDATES` 和各消融的同父冲突/跨父排序也按该文件固定。编写候选失败与模型异常用例：已有 `M0` 时回退后的实例 ID 图逐像素相同，尚无 `M0` 时只记录 `PREDICTION_UNAVAILABLE` 且阻断评价；运行错误与候选证据分别符合各自 Schema。四种轻度变换必须在变换后的原始 RGB 上重算局部证据；单视图支持、分区 ARI=0.89 或验证器分数低于阈值时均应拒绝。**先完成 T12：种子 29/43 重跑完整 OOF→候选→独立标签→验证器/风险模型链，复用已验证的种子 17，准备全部对照和消融，记录全部模型哈希、速度及 C1 结果；然后从 `policy_all_dev.json` 执行 T13 冻结。**验证：`pytest tests/test_policy.py tests/test_resume.py -q`，生成 `reports/ablations_dev.json`、`runs/latest/all_models.sha256` 和含全部种子的 `policy_frozen.json`。

另写一组方法差异反例：`ALL_CANDIDATES` 在 C1 全真但 `g/verifier/OOD/视图=null` 时可合法接受；`FULL` 同样记录必须拒绝。A 的逐图累计预计伤害超过冻结预算、C 已启用但 `E_image≤0` 或 `E_specific≤0` 或伪切界不足 8 条、B 置换映射与 `FULL` 原分数不符时，`infer audit` 必须失败。四视图支持布尔值即使填真，若从 RGB 与冻结模型重算不符也必须失败。`mechanism_scores.jsonl` 缺合法候选行时阻断 B/H3 关联；几何版单候选诊断缺分数时记录原因，不把它当作 `FULL` 决策失败。

### Task 8：校准审计及独立外测

冻结后按 T14 顺序先用只含图像的 `cal_images.json` 生成全部预测，`infer audit` 检查 C1 和覆盖完整性，再让封存评价器只读 `--predictions`、`--seal` 与审计报告；默认只对种子 17 主策略尝试 C3。T15 对**全部冻结种子与对照**同样先预测、审计，再进行唯一外测，生成 `reports/h3_association.json`。评价器不得内部重跑推理。写测试：`n=0` 风险必须 null；`k=0,n=20,delta=.05` 的 CP 上界约 0.139，大于 0.10；组数不足或来源关系未知不得发 C3；H3 分组 AUROC 对缺分数候选报告覆盖率，门槛不足标 `H3_NOT_ESTIMABLE`；运行错误中的两份掩膜哈希不同、C1 中 `child_count` 与 ID 列表数不同均必须被审计阻断。验证：`pytest tests/test_statistics.py -q`、封存评估命令、`reports/results.md` 中三种种子、全部对照和全部数据集齐全。T16 运行 `python -m nrr evaluate aggregate --results reports/external_results.json --h3 reports/h3_association.json --all-seeds-output reports/all_seeds.json --comparison reports/comparison.md`，由 T15 的 JSON 生成两份汇总文件，不能再训练或打开真值。

### Task 9：图表与论文初稿

按 `05-paper-protocol.md` 与 SOP 第 9 节的 `paper journal-screen`、`paper draft` 命令生成图表源 CSV、论文草稿和 `claim_ledger.csv`；对稿件内每个数值匹配 `reports/*.json` 里的字段。文献 DOI 由 Crossref/Europe PMC 再核对，访问不到全文的引用标记 `ABSTRACT_ONLY`。按 `08-literature-journal-screen.md` 生成 `reports/journal_screen.csv`；拿不到可审计的 2026 中科院分区来源则填 `UNVERIFIED`，不阻断科研结果报告。验证：`python -m nrr paper audit --manuscript paper/manuscript.md --ledger paper/claim_ledger.csv --results reports/external_results.json --output reports/evidence_audit.md`；无来源数字、错误 C3 表述或缺负结果讨论则失败。

### Task 10：总体验收与中断恢复演练

正常完成 T16 后运行全部测试，核对 `tasks.json` 每项产物的存在性及 SHA-256；模拟中断并重启一次。运行 SOP 第 9 节的 `paper decide`，完成 `runs/latest/decision.json`、`reports/evidence_audit.md`、`paper/manuscript.md`。若 T08/T11 早停，改走 `tasks.json.terminal_branches.early_scientific_stop` 的 `paper negative-draft/audit/decide` 命令；能力阻断和封存泄漏走各自终支，不向不存在的外测 JSON 取数。`decision.json` 只能依据门槛取 `CONTINUE`、`REVISE_ON_NEW_DATA`、`STOP_NEGATIVE_RESULT`、`BLOCKED_CAPABILITY`、`DATA_BLOCKED` 或 `TEST_LEAKED`。没有外测 JSON 时不允许标记研究已完成外部验证。

## 最终交付与文件检查

WorkBuddy 最后用一段中文说明：哪项假设成立、数据与来源组数、三个种子的主指标、真实误伤与覆盖率、C1/C2/C3 级别、每完整配置训练耗时、失败样本、尚不能支持的主张，以及稿件路径。不得只汇报“实验完成”。保留运行时环境锁定文件和所有失败试验日志；本计划不要求 Git 写操作。
