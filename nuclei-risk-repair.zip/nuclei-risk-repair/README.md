# 粘连细胞核风险感知局部纠错：研究执行包

版本：`nrr-2026-10-07-v3`。状态：**研究设计已编写；本仓库尚未实现算法或运行实验。**

本包用于让 WorkBuddy + Kimi K3 在用户自己的研究机器上按固定协议完成代码、实验、统计和论文初稿。首次使用时，把整个目录复制到研究机器的独立项目目录，把 [`START_HERE.txt`](START_HERE.txt) 作为 WorkBuddy 的首条任务。WorkBuddy 应读取所有链接文件并从“环境预检”任务开始；文中 `nrr ...` 是**待它实现的统一命令接口**，现在不能直接运行。

| 文件 | 用途 |
| --- | --- |
| [`01-proposal.md`](01-proposal.md) | 开题报告：研究问题、创新、技术路线、预期结果与风险 |
| [`02-sop.md`](02-sop.md) | 逐阶段实验 SOP、命令契约、资源预算和异常处理 |
| [`03-agent-handbook.md`](03-agent-handbook.md) | WorkBuddy/Kimi K3 自主执行规则与恢复机制 |
| [`04-statistics.md`](04-statistics.md) | 风险、收益、统计单位和结论级别的精确定义 |
| [`05-paper-protocol.md`](05-paper-protocol.md) | 论文结构、表图清单、参考文献和证据核对 |
| [`06-task-plan.md`](06-task-plan.md) | 分任务实现计划、文件职责和验收输出 |
| [`07-innovation-options.md`](07-innovation-options.md) | 风险预算、负对照、反事实证据与增量止损条件 |
| [`08-literature-journal-screen.md`](08-literature-journal-screen.md) | 已核 DOI 的 2026 近邻工作和中科院 Q2 核查流程 |
| [`protocol.json`](protocol.json) | 冻结的研究配置与显式门槛；运行前制作版本化副本 |
| [`tasks.json`](tasks.json) | Agent 任务 DAG、前置条件、完成证据 |
| [`schemas/evidence.schema.json`](schemas/evidence.schema.json) | 无标注推理决策记录的 JSON Schema |
| [`schemas/evidence.example.json`](schemas/evidence.example.json) | 推理审计记录的非实验示例，不含真值 |
| [`schemas/runtime-error.schema.json`](schemas/runtime-error.schema.json) | 图像/模型等运行失败的独立 JSON Schema |
| [`schemas/runtime-error.example.json`](schemas/runtime-error.example.json) | 已有 M0 时的回退错误示例，不含真值 |
| [`schemas/runtime-error.no-m0.example.json`](schemas/runtime-error.no-m0.example.json) | 尚无 M0 时只报失败的示例 |
| [`references.bib`](references.bib) | 已核对 DOI 的核心文献 |
| [`CHECKSUMS.sha256`](CHECKSUMS.sha256) | 交付文件校验和；复制后可核对完整性 |
| [`START_HERE.txt`](START_HERE.txt) | 可直接粘贴到 WorkBuddy 的首条指令 |

## 研究边界

- **允许**使用公开数据的已有掩膜训练基线、证据模型、风险模型，并在独立开发集做校准。
- **实际纠错时**只读取图像、冻结模型、原始预测和训练阶段得到的常数；不读取该图的真值、歧义区域标注或任何测试分数。全部合法候选（含被拒绝者）的提案与证据会先落盘，封存评价器事后只读这些文件复算成败。
- “自证”分三层：前景守恒等可精确检查的不变量；图像证据与扰动稳定性等无标注代理证据；封存真值后的外部评估。H3 还预设了图像证据关联的候选级 AUROC、可评分覆盖率和来源组重抽样。前两层不证明单张图的生物学真值。
- 不把贴在像素上的成千上万个细胞核当成独立临床样本。NuInsSeg 缺少充分可审计的患者/切片来源标识时，不宣称患者级有限样本统计保证。
- 默认目标是**实证风险感知**。若校准组数与数据独立性达不到 [`04-statistics.md`](04-statistics.md) 的条件，自动输出 `C3_NOT_ESTABLISHED`，论文中不得写“风险有形式化保证”。
- 本包没有用户机器上的 GPU、WorkBuddy 或 Kimi K3 凭证，无法预先验证三者的实际运行能力；SOP 包含能力预检及故障恢复任务。目标期刊的 2026 中科院 Q2 与 SCIE 状态尚需按可审计来源核查。

## 最短阅读顺序

先运行 `python validate_package.py` 检查文档契约与交付哈希，再读开题报告、创新性方案和 SOP 的数据与冻结规则，最后执行 `START_HERE.txt`。完成后优先打开 `runs/latest/decision.json`、`reports/results.md` 和 `paper/manuscript.md`；这些输出由未来的执行 Agent 生成，此目录当前不含实验结果。
