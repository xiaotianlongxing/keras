# 2026 文献定位与目标期刊核查

核查基准日：2026-10-07。以下 DOI、题名、期刊和年份来自 Crossref / Europe PMC 元数据；相近工作的内容判断仅依据其公开摘要，标记为 `ABSTRACT_ONLY`，正式写作前须读全文核对。**中科院分区不等于 JCR Q2，且会按版本和学科变化；本包没有取得可审计的 2026 中科院分区原始记录，因此不把任何候选期刊断言为“已核实 Q2”。**

LSP-DETR 的 Crossref DOI 创建于 2026-09，元数据刊期为 2026-12；截至本核查日把它作为已登记的前沿近邻，不能把尚未来到的 12 月刊期写成已完成出版事实。正式投稿前再次核对在线发表与最终卷期。

## 直接相关的 2026 工作

| 工作与 DOI | 公开摘要显示的重点 | 对本课题的约束 |
| --- | --- | --- |
| [LSP-DETR, CMPB](https://doi.org/10.1016/j.cmpb.2026.109614) | 高效全切片核实例分割、重叠和标注不确定性 | 不能把 DETR、重叠分离或处理歧义标注单独当首创；本文检验已输出实例图的**相对修改风险** |
| [CellViT++, CMPB](https://doi.org/10.1016/j.cmpb.2025.109206) | 基础模型上的高效核分割与分类 | 单说“轻量化”不够；本文须展示本机实际时间/显存和编辑可靠性 |
| [FKDNuSeg, MIA](https://doi.org/10.1016/j.media.2026.104089) | 知识蒸馏、边缘/曲率任务、粘连与重叠核分离 | 不能把边缘分支或分裂粘连核本身写成新贡献 |
| [Cooperative Fine-Grained Refinement of SAM, MIA](https://doi.org/10.1016/j.media.2026.104144) | SAM 参数高效适配与边界细化 | “SAM+细化”已有；本方案不用微调大型 SAM，重点是可拒绝的后验编辑 |
| [Self-Refining SAM, Diagnostics](https://doi.org/10.3390/diagnostics16091370) | 点标注、对比学习、伪标签自演化及双解码一致性 | 一致性筛选不是本文独有；须证明它能预测**某一次分裂**的真实成败 |
| [ConfIC-RCA, IEEE TMI](https://doi.org/10.1109/tmi.2026.3679618) | 无真值分割质量估计及带统计条件的质量区间 | 不能声称首个无真值质量预测；本文 C3 若样本假设不足应明确未建立 |
| [Ruckli 等, Scientific Reports](https://doi.org/10.1038/s41598-026-57383-8) | 3D 髋关节 MRI 中以不确定性和临床指标敏感性构成风险分数，引导局部人工/区域纠错 | “风险引导局部纠错”并非本文独有；本文须证明 2D H&E 核实例**自动分裂动作相对保留**的伤害—覆盖增量 |
| [NucFuseRank, Bioengineering](https://doi.org/10.3390/bioengineering13080886) | 多公开核数据集融合、排名与跨集验证 | 独立外测须查重和预训练谱系；不得用融合训练数据污染封存测试 |
| [AGAFNet, IEEE TIP](https://doi.org/10.1109/tip.2025.3646471) | 注意力融合网络做核分割/分类 | 堆注意力模块难构成差异；以固定候选、风险—覆盖及无标注审核为主线 |

补充近邻：[RCA 2017](https://doi.org/10.1109/tmi.2017.2665165) 已做无真值质量估计；[QCResUNet](https://doi.org/10.1016/j.media.2025.103718) 在 2025 在线发表、2026 卷期中做主体/像素质量预测；[2025 弱监督伪标签纠错](https://doi.org/10.1016/j.artmed.2025.103113) 处理训练伪标签。[Luna 等 2024](https://doi.org/10.1016/j.compbiomed.2024.108015) 已做重叠核的多尺度簇细化和 amodal 分割；[Liu 等 2024 卷期、2023 在线](https://doi.org/10.1007/s11517-023-02947-3) 已做乳腺 H&E 核检测定位的迭代纠错；[NuGraph 2026 预印本](https://doi.org/10.64898/2026.05.16.725603) 做 3D 核片段的图推理纠错。它们均须进入 T04 的全文对比矩阵；此处仅据摘要判断对象与动作定义，标 `ABSTRACT_ONLY`，不据此断言它们没有相同机制。正式对比表要核实是否也有“接受/拒绝某次编辑”的风险、相同候选对照和封存评价。

## 本文应收缩到的贡献

1. **动作相对性**：标签是“接受此分裂相对保留原预测是否伤害”，而不是整张图的绝对质量。
2. **非空洞选择**：在相同候选和匹配编辑覆盖率下比较收益及伤害；“拒绝全部”不是成功。
3. **两类证据**：C1 的前景/局部不变量可严格复验；C2 的原始图像关系、扰动与可选反事实证据只能预测真实收益，需要外部真值事后验证。
4. **低资源与可迁移**：每完整配置在 16GB 显存和 170 分钟墙钟硬界内；不同基线若执行，须同输入定义及公平训练预算。

这组贡献是否足以投稿，取决于真实增量结果。若风险模块不优于简单分裂阈值、C2 证据与真值收益不相关或外部 PQ/计数退化，论文必须降低主张或转负结果分析。

T04 的 `reports/novelty_precheck.md` 是**训练前**近邻核查：逐篇记录 DOI、年份、可访问全文/摘要、研究对象、是否预测某次“保留/编辑”的差值、是否给出候选级误伤、是否在同一候选与匹配覆盖率下比较、是否测试无该图标注的证据。现有表只列优先核对论文，不可代替这项矩阵。若关键全文不可得，记 `ABSTRACT_ONLY` 并保留不确定性；T17 按投稿日再次检索、核对全文和期刊状态。

## 2026 中科院 Q2 投稿目标的审计 SOP

初步从研究主题和 2026 近邻论文考虑 **Computer Methods and Programs in Biomedicine（CMPB）** 与 **Biomedical Signal Processing and Control（BSPC）**；也可扫描 **Artificial Intelligence in Medicine**、**Computerized Medical Imaging and Graphics**。这只是**主题匹配候选**，其 2026 中科院分区、是否 SCIE、文章类型和处理时长均尚未在本包核实。MIA、IEEE TMI、IEEE TIP 在表中是高强度相关工作来源，不自动列作本项目 Q2 目标。

WorkBuddy/Kimi 在 T17 前生成 `reports/journal_screen.csv`，每行至少填：`journal,ISSN,CAS_version_used,major_category,major_zone,minor_category,minor_zone,SCIE_status,scope_evidence_url,2026_relevant_DOI,article_type,APC_or_page_charge,submission_requirements,checked_at_utc,source_capture_path`。从单位图书馆或可核验的中科院分区查询渠道记录**截至核查日最新已发布且单位认可的版本、日期和截图/导出件**，再核对 Web of Science Master Journal List 的 SCIE 状态及期刊官网作者指南。若 2026 版尚未发布，应如实写实际所用年度；若无法访问权威分区，填 `UNVERIFIED`，不能用第三方页面或 JCR 四分位冒充中科院 Q2。

选择顺序：首先筛掉未证实符合用户目标的期刊；再看实际结果是否匹配近期论文的主题、方法强度和文章类型；最后比较格式、费用与时间。没有外部结果时只保留候选名单，不写“确保 2026 年录用”。审稿和接受日期不由研究 Agent 控制。
