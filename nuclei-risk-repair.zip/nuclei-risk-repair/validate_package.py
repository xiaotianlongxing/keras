"""Check the static research handoff package; this does not run experiments."""

from __future__ import annotations

import copy
import json
import math
import re
from hashlib import sha256
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
REQUIRED_FILES = [
    "README.md",
    "01-proposal.md",
    "02-sop.md",
    "03-agent-handbook.md",
    "04-statistics.md",
    "05-paper-protocol.md",
    "06-task-plan.md",
    "07-innovation-options.md",
    "08-literature-journal-screen.md",
    "START_HERE.txt",
    "protocol.json",
    "tasks.json",
    "schemas/evidence.schema.json",
    "schemas/evidence.example.json",
    "schemas/runtime-error.schema.json",
    "schemas/runtime-error.example.json",
    "schemas/runtime-error.no-m0.example.json",
    "references.bib",
    "validate_package.py",
    "CHECKSUMS.sha256",
]
FORBIDDEN_TRUTH_FIELDS = {
    "ground_truth",
    "actual_harm",
    "test_dice",
    "ambiguous_region_mask",
}
SHA256_RE = re.compile(r"[a-f0-9]{64}")
SUPPORTED_SCHEMA_KEYS = {
    "$schema",
    "$id",
    "title",
    "type",
    "required",
    "properties",
    "additionalProperties",
    "items",
    "enum",
    "const",
    "pattern",
    "minLength",
    "minimum",
    "maximum",
    "minItems",
    "maxItems",
    "uniqueItems",
    "allOf",
    "anyOf",
    "if",
    "then",
    "else",
    "not",
}


def require(condition: bool, message: str) -> None:
    if not condition:
        raise SystemExit(message)


def reject_duplicate_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"Duplicate JSON key: {key}")
        result[key] = value
    return result


def reject_nonfinite_constant(value: str) -> None:
    raise ValueError(f"Non-finite JSON constant: {value}")


def read_json(relative: str) -> dict[str, Any]:
    try:
        value = json.loads(
            (ROOT / relative).read_text(encoding="utf-8"),
            object_pairs_hook=reject_duplicate_keys,
            parse_constant=reject_nonfinite_constant,
        )
    except (OSError, ValueError) as error:
        raise SystemExit(f"Invalid JSON in {relative}: {error}") from error
    require(isinstance(value, dict), f"JSON root must be an object: {relative}")
    return value


def is_number(value: Any) -> bool:
    return (
        isinstance(value, (int, float))
        and not isinstance(value, bool)
        and math.isfinite(value)
    )


def json_equal(left: Any, right: Any) -> bool:
    if isinstance(left, bool) or isinstance(right, bool):
        return type(left) is type(right) and left == right
    return left == right


def matches_type(value: Any, type_name: str) -> bool:
    if type_name == "null":
        return value is None
    if type_name == "boolean":
        return isinstance(value, bool)
    if type_name == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    if type_name == "number":
        return is_number(value)
    if type_name == "string":
        return isinstance(value, str)
    if type_name == "object":
        return isinstance(value, dict)
    if type_name == "array":
        return isinstance(value, list)
    raise SystemExit(f"Unsupported JSON Schema type: {type_name}")


def check_supported_schema(rule: dict[str, Any], where: str) -> None:
    require(isinstance(rule, dict), f"Schema node is not an object: {where}")
    unknown = set(rule) - SUPPORTED_SCHEMA_KEYS
    require(not unknown, f"Unsupported Schema keywords at {where}: {sorted(unknown)}")
    for name, child in rule.get("properties", {}).items():
        check_supported_schema(child, f"{where}.properties.{name}")
    if "items" in rule:
        check_supported_schema(rule["items"], f"{where}.items")
    for key in ("allOf", "anyOf"):
        for index, child in enumerate(rule.get(key, [])):
            check_supported_schema(child, f"{where}.{key}[{index}]")
    for key in ("if", "then", "else", "not"):
        if key in rule:
            check_supported_schema(rule[key], f"{where}.{key}")


def schema_matches(value: Any, rule: dict[str, Any]) -> bool:
    """Evaluate every keyword used by the two bundled Draft 2020-12 schemas."""
    type_spec = rule.get("type")
    if type_spec is not None:
        allowed_types = type_spec if isinstance(type_spec, list) else [type_spec]
        if not any(matches_type(value, type_name) for type_name in allowed_types):
            return False
    if "const" in rule and not json_equal(value, rule["const"]):
        return False
    if "enum" in rule and not any(json_equal(value, item) for item in rule["enum"]):
        return False
    if isinstance(value, str):
        if len(value) < rule.get("minLength", 0):
            return False
        if "pattern" in rule and re.search(rule["pattern"], value) is None:
            return False
    if is_number(value):
        if "minimum" in rule and value < rule["minimum"]:
            return False
        if "maximum" in rule and value > rule["maximum"]:
            return False
    if isinstance(value, list):
        if len(value) < rule.get("minItems", 0):
            return False
        if "maxItems" in rule and len(value) > rule["maxItems"]:
            return False
        if rule.get("uniqueItems", False):
            canonical = [
                json.dumps(item, sort_keys=True, ensure_ascii=False) for item in value
            ]
            if len(set(canonical)) != len(canonical):
                return False
        if "items" in rule and not all(
            schema_matches(item, rule["items"]) for item in value
        ):
            return False
    if isinstance(value, dict):
        if any(key not in value for key in rule.get("required", [])):
            return False
        properties = rule.get("properties", {})
        if rule.get("additionalProperties") is False and set(value) - set(properties):
            return False
        if any(
            not schema_matches(value[key], child)
            for key, child in properties.items()
            if key in value
        ):
            return False
    if any(not schema_matches(value, child) for child in rule.get("allOf", [])):
        return False
    if "anyOf" in rule and not any(
        schema_matches(value, child) for child in rule["anyOf"]
    ):
        return False
    if "if" in rule:
        branch = "then" if schema_matches(value, rule["if"]) else "else"
        if branch in rule and not schema_matches(value, rule[branch]):
            return False
    if "not" in rule and schema_matches(value, rule["not"]):
        return False
    return True


def check_checksum_manifest() -> None:
    missing = [name for name in REQUIRED_FILES if not (ROOT / name).is_file()]
    require(not missing, f"Missing required files: {missing}")
    expected = set(REQUIRED_FILES) - {"CHECKSUMS.sha256"}
    entries: dict[str, str] = {}
    for line in (ROOT / "CHECKSUMS.sha256").read_text(encoding="utf-8").splitlines():
        match = re.fullmatch(r"([a-f0-9]{64})  (.+)", line)
        require(match is not None, f"Invalid checksum line: {line}")
        digest, relative = match.groups()
        path = Path(relative)
        require(
            not path.is_absolute()
            and ".." not in path.parts
            and relative not in entries,
            f"Invalid checksum path: {relative}",
        )
        require(relative in expected, f"Unexpected checksum entry: {relative}")
        full_path = ROOT / path
        require(full_path.is_file() and not full_path.is_symlink(), f"Missing file: {relative}")
        require(
            sha256(full_path.read_bytes()).hexdigest() == digest,
            f"Checksum mismatch: {relative}",
        )
        entries[relative] = digest
    require(set(entries) == expected, f"Checksum coverage mismatch: {sorted(expected - set(entries))}")


def check_protocol(protocol: dict[str, Any], task_data: dict[str, Any]) -> None:
    require(
        protocol.get("protocol_version") == task_data.get("version"),
        "Protocol/task versions differ",
    )
    label_policy = protocol["label_policy"]
    require(label_policy["training_labels_allowed"] is True, "Training labels must be allowed")
    require(label_policy["inference_labels_forbidden"] is True, "Inference labels must be forbidden")
    ratios = protocol["data"]["fit_dev_cal_ratios"]
    require(
        isinstance(ratios, list)
        and len(ratios) == 3
        and all(is_number(x) and x > 0 for x in ratios)
        and abs(sum(ratios) - 1) < 1e-12,
        "Invalid fit/dev/cal ratios",
    )
    require(protocol["model"]["seeds"] == [17, 29, 43], "Seed list changed")
    require(protocol["model"]["oof_group_folds"] >= 2, "OOF folds insufficient")
    candidates = protocol["candidates"]
    require(candidates["min_children"] == 2 and candidates["max_children"] == 3, "Invalid child count bounds")
    require(protocol["verifier"]["output_semantics"] == "uncalibrated_same_nucleus_score", "Verifier score semantics changed")
    require(protocol["verifier"]["geometry_only_negative_control"] is True, "Geometry-only negative control missing")
    require(
        protocol["verifier"]["pair_rgb_patch_size"] == 5
        and protocol["verifier"]["model_architecture"] == "two_hidden_layer_mlp"
        and protocol["verifier"]["hidden_widths"] == [64, 32]
        and protocol["verifier"]["pair_distance_bin_edges_pixels"] == [0, 1, 2, 4, 8]
        and protocol["verifier"]["pair_direction_rule"]
        == "horizontal_if_abs_dx_ge_2_abs_dy_vertical_if_abs_dy_ge_2_abs_dx_else_diagonal",
        "Verifier pair-feature protocol changed",
    )
    risk = protocol["risk"]
    require(risk["c3_default_status"] == "C3_NOT_ESTABLISHED", "C3 status mismatch")
    require(risk["invalid_local_utility_with_valid_truth"] == 0, "Invalid-local utility mismatch")
    require(risk["min_supporting_views"] == 2, "View support requirement changed")
    require(
        risk["min_geometric_supporting_views"] >= 1
        and risk["min_photometric_supporting_views"] >= 1,
        "Geometric/photometric support missing",
    )
    require(0 < risk["view_partition_ari_min"] <= 1, "Invalid view ARI")
    require(
        risk["decision_sort"]
        == "harm_probability_asc_then_predicted_gain_desc_then_parent_id_then_candidate_sha256",
        "Decision order mismatch",
    )
    innovation = protocol["innovation_extensions"]
    require(innovation["required_negative_controls"] is True, "Negative control is required")
    require(
        innovation["pseudo_seam_count"] == 8
        and innovation["pseudo_seam_angle_candidates"] >= 8
        and 0 < innovation["pseudo_seam_max_partition_ari"] < 1,
        "Invalid pseudo-seam settings",
    )
    require(
        innovation["counterfactual_holdout_fraction"] == 0.2
        and innovation["counterfactual_holdout_block_size"] == 2
        and innovation["counterfactual_fit_holdout_gap_pixels"] == 2
        and innovation["counterfactual_fit_holdout_gap_metric"] == "chebyshev"
        and innovation["counterfactual_min_fit_pixels_per_child"] >= 16
        and innovation["counterfactual_min_holdout_pixels_per_child"] >= 8
        and innovation["stain_conversion"]
        == "skimage.color.rgb2hed_fixed_matrix_rgb_0_1"
        and innovation["counterfactual_min_image_score_exclusive"] == 0
        and innovation["counterfactual_min_specificity_score_exclusive"] == 0
        and len(innovation["counterfactual_features"]) == 4,
        "Counterfactual evidence definition is incomplete",
    )
    comparisons = protocol["comparisons"]
    require(comparisons["threshold_count_per_control"] <= 24, "Comparison search exceeds budget")
    require(
        comparisons["matched_group_coverage_tolerance"]
        == innovation["matched_coverage_tolerance"],
        "Coverage tolerance mismatch",
    )
    search = protocol["dev_search"]
    require(
        search["max_coarse_policies"] + search["max_refinement_policies"] <= 24,
        "Main policy search exceeds budget",
    )
    compute = protocol["compute"]
    require(
        compute["geometry_verifier_included_in_training_budget"] is True,
        "Geometry-only verifier is excluded from training budget",
    )
    require(
        0 < compute["max_total_train_wall_seconds"] <= 9000
        and compute["max_total_train_wall_seconds"]
        <= compute["max_complete_configuration_wall_seconds"]
        <= 10200,
        "Compute limits exceed the registered 150/170 minute budget",
    )
    statistics = protocol["statistics"]
    require(statistics["allow_test_driven_changes"] is False, "Test-driven changes cannot be enabled")
    require(statistics["aji_variant"] == "original_aji", "AJI definition changed")
    require(statistics["h3_primary_dataset"] == "MoNuSeg", "H3 primary dataset changed")
    require(statistics["h3_primary_seed"] == 17, "H3 primary seed changed")
    require(
        statistics["h3_primary_score"] == "verifier_score"
        and statistics["h3_primary_label"] == "help",
        "H3 primary association changed",
    )
    require(
        statistics["h3_min_independent_groups"] >= 10
        and statistics["h3_min_candidates_per_class"] >= 20
        and 0 < statistics["h3_min_candidate_score_coverage"] <= 1
        and 0 < statistics["h3_min_group_score_coverage"] <= 1,
        "H3 estimability limits missing",
    )
    require(
        statistics["h4_analysis_unit"] == "eligible_parent_instance"
        and statistics["h4_boundary_to_ambiguity_pixels"] == 5
        and statistics["h4_status"] == "EXPLORATORY_ONLY",
        "H4 exploratory analysis changed",
    )


def check_tasks(task_data: dict[str, Any]) -> int:
    tasks = task_data["tasks"]
    require(isinstance(tasks, list), "Tasks must be a list")
    ids = [task["id"] for task in tasks]
    require(ids == [f"T{i:02d}" for i in range(19)], "Task IDs must be T00..T18")
    seen: set[str] = set()
    for task in tasks:
        task_id = task["id"]
        require(task["outputs"] and task["gate"], f"Task has no output or gate: {task_id}")
        require(
            all(predecessor in seen for predecessor in task["depends_on"]),
            f"Task dependency is absent or out of order: {task_id}",
        )
        seen.add(task_id)
    by_id = {task["id"]: task for task in tasks}
    needed = {
        "T04": {"reports/metrics_selfcheck.json", "reports/novelty_precheck.md"},
        "T05": {"runs/latest/oof/", "runs/latest/oof/time_budget.json"},
        "T06": {"runs/latest/baseline/model.pt", "runs/latest/dev_baseline/"},
        "T07": {"runs/latest/fit_candidates_base/", "runs/latest/dev_candidates_base/"},
        "T08": {"runs/latest/d_trigger.json", "runs/latest/fit_candidates/", "runs/latest/dev_candidates/"},
        "T10": {"runs/latest/fit_candidate_labels.jsonl", "reports/label_audit.json"},
        "T11": {"reports/negative_controls_dev.json"},
        "T12": {"runs/latest/replicate_models/", "runs/latest/replicate_train_times.json", "runs/latest/policy_all_dev.json", "runs/latest/all_models.sha256", "reports/invariants_dev.json"},
        "T13": {"runs/latest/policy_frozen.json"},
        "T14": {"runs/latest/cal_predictions/", "reports/invariants_cal.json", "reports/calibration.json"},
        "T15": {"runs/latest/external_predictions/", "reports/invariants_external.json", "reports/external_results.json", "reports/h3_association.json", "reports/results.md"},
        "T16": {"reports/all_seeds.json", "reports/comparison.md"},
        "T17": {"paper/manuscript.md", "paper/claim_ledger.csv", "paper/figures/", "reports/journal_screen.csv"},
        "T18": {"runs/latest/decision.json", "reports/evidence_audit.md"},
    }
    for task_id, outputs in needed.items():
        require(outputs <= set(by_id[task_id]["outputs"]), f"Missing {task_id} outputs: {sorted(outputs - set(by_id[task_id]['outputs']))}")
    require(by_id["T16"]["depends_on"] == ["T15"], "T16 must only summarize T15")
    branches = task_data["terminal_branches"]
    require(
        branches["early_scientific_stop"]["trigger_tasks"] == ["T08", "T11"]
        and branches["early_scientific_stop"]["skipped_status"] == "SKIPPED_EARLY_STOP",
        "Early-stop branch is missing",
    )
    require(
        {"paper/manuscript.md", "reports/negative_result_review.md", "runs/latest/decision.json"}
        <= set(branches["early_scientific_stop"]["outputs"]),
        "Early-stop outputs are incomplete",
    )
    require(
        branches["capability_blocked"]["status"] == "BLOCKED_CAPABILITY"
        and branches["data_blocked"]["status"] == "DATA_BLOCKED"
        and branches["test_leaked"]["status"] == "TEST_LEAKED",
        "Blocked/leaked branch statuses mismatch",
    )
    sop = (ROOT / "02-sop.md").read_text(encoding="utf-8")
    required_commands = [
        "--output runs/latest/fit_candidates_base/",
        "--output runs/latest/dev_candidates_base/",
        "--trigger-out runs/latest/d_trigger.json",
        "--mode-file runs/latest/d_trigger.json",
        "--labels runs/latest/fit_candidate_labels.jsonl",
        "--output-time runs/latest/oof/time_budget.json",
        "--output runs/latest/replicate_models/ --output-time runs/latest/replicate_train_times.json",
        "--dev-policy runs/latest/policy_all_dev.json",
        "--predictions runs/latest/cal_predictions/",
        "--predictions runs/latest/external_predictions/",
        "evaluate aggregate --results reports/external_results.json --h3 reports/h3_association.json --all-seeds-output reports/all_seeds.json --comparison reports/comparison.md",
        "--output paper/manuscript.md --ledger paper/claim_ledger.csv --figures paper/figures/",
        "--output runs/latest/decision.json",
        "paper negative-draft --state state.json --run runs/latest/ --available-reports reports/",
    ]
    require(
        all(command in sop for command in required_commands),
        "SOP commands do not cover the task outputs",
    )
    return len(tasks)


def sample_candidate_semantics(sample: dict[str, Any], protocol: dict[str, Any]) -> bool:
    c1 = sample["c1"]
    flags = [
        "child_count_valid",
        "new_ids_fresh",
        "new_ids_unique",
        "foreground_equal",
        "outside_parent_equal",
        "children_nonempty",
        "children_connected",
        "union_equals_parent",
        "budget_ok",
    ]
    if c1["child_count"] != len(c1["child_instance_ids"]):
        return False
    if c1["child_count_valid"] != (c1["child_count"] in (2, 3)):
        return False
    if c1["all_pass"] != all(c1[key] for key in flags):
        return False
    if sample["decision"] != "ACCEPT":
        return True
    if not (
        c1["all_pass"]
        and c1["child_count"] in (2, 3)
        and len(set(c1["child_instance_ids"])) == c1["child_count"]
        and c1["child_instance_ids"].count(sample["parent_instance_id"]) == 1
    ):
        return False
    if sample["method_id"] != "FULL":
        return True
    views = sample["view_support"]
    if not isinstance(views, dict):
        return False
    extensions = sample["policy_extension_evidence"]
    budget_status = extensions["risk_budget_status"]
    if budget_status == "PASS":
        if not (
            is_number(extensions["risk_budget_limit"])
            and is_number(extensions["risk_budget_used_before"])
            and is_number(sample["predicted_harm_probability"])
            and extensions["risk_budget_used_before"]
            + sample["predicted_harm_probability"]
            <= extensions["risk_budget_limit"] + 1e-12
        ):
            return False
    elif budget_status != "NOT_ENABLED":
        return False
    if extensions["counterfactual_status"] == "PASS" and not (
        is_number(extensions["counterfactual_image_score"])
        and extensions["counterfactual_image_score"]
        > protocol["innovation_extensions"]["counterfactual_min_image_score_exclusive"]
        and is_number(extensions["counterfactual_specificity_score"])
        and extensions["counterfactual_specificity_score"]
        > protocol["innovation_extensions"]["counterfactual_min_specificity_score_exclusive"]
        and extensions["counterfactual_valid_pseudo_seams"]
        == protocol["innovation_extensions"]["pseudo_seam_count"]
    ):
        return False
    return (
        sample["score_missing"] is False
        and is_number(sample["predicted_local_gain"])
        and sample["predicted_local_gain"]
        >= protocol["risk"]["minimum_predicted_local_gain"]
        and extensions["counterfactual_status"] in ("NOT_ENABLED", "PASS")
        and sum(views.values()) >= protocol["risk"]["min_supporting_views"]
        and sum(views[key] for key in ("horizontal_flip", "rotate_90")) >= 1
        and sum(views[key] for key in ("brightness_plus_5pct", "brightness_minus_5pct")) >= 1
    )


def sample_runtime_semantics(sample: dict[str, Any]) -> bool:
    status = sample["status"]
    if status == "ABSTAIN_RUNTIME":
        return (
            sample["m0_available"] is True
            and sample["mask_fallback_written"] is True
            and sample["m0_array_sha256"] == sample["mask_after_array_sha256"]
        )
    if status == "PREDICTION_UNAVAILABLE":
        return (
            sample["m0_available"] is False
            and sample["mask_fallback_written"] is False
            and sample["m0_array_sha256"] is None
            and sample["mask_after_array_sha256"] is None
        )
    if status == "FALLBACK_WRITE_FAILED":
        return sample["m0_available"] is True and sample["mask_fallback_written"] is False
    return False


def check_schemas(protocol: dict[str, Any]) -> str:
    evidence_schema = read_json("schemas/evidence.schema.json")
    runtime_schema = read_json("schemas/runtime-error.schema.json")
    evidence = read_json("schemas/evidence.example.json")
    runtime = read_json("schemas/runtime-error.example.json")
    no_m0 = read_json("schemas/runtime-error.no-m0.example.json")
    samples = [
        (evidence_schema, evidence, "evidence"),
        (runtime_schema, runtime, "runtime fallback"),
        (runtime_schema, no_m0, "runtime no-M0"),
    ]
    for schema, sample, name in samples:
        check_supported_schema(schema, name)
        require(
            schema.get("$schema") == "https://json-schema.org/draft/2020-12/schema",
            f"Wrong Schema draft: {name}",
        )
        require(schema.get("additionalProperties") is False, f"Extra fields allowed: {name}")
        require(not FORBIDDEN_TRUTH_FIELDS & set(schema["properties"]), f"Truth fields exposed: {name}")
        require(not FORBIDDEN_TRUTH_FIELDS & set(sample), f"Truth fields in sample: {name}")
        require(schema_matches(sample, schema), f"Example does not match Schema: {name}")
    view_keys = set(evidence_schema["properties"]["view_support"]["required"])
    require(
        view_keys == set(protocol["risk"]["stability_views"]),
        "View evidence does not match the protocol",
    )
    require(sample_candidate_semantics(evidence, protocol), "ACCEPT example fails semantic checks")
    require(sample_runtime_semantics(runtime), "Runtime fallback example is not a true fallback")
    require(sample_runtime_semantics(no_m0), "No-M0 example invents a fallback")
    control = copy.deepcopy(evidence)
    control["method_id"] = "ALL_CANDIDATES"
    control["predicted_local_gain"] = None
    control["predicted_harm_probability"] = None
    control["verifier_score"] = None
    control["score_missing"] = True
    control["ood_score"] = None
    control["view_support"] = None
    control["policy_extension_evidence"] = {
        "risk_budget_status": "NOT_ENABLED",
        "risk_budget_limit": None,
        "risk_budget_used_before": None,
        "counterfactual_status": "NOT_ENABLED",
        "counterfactual_image_score": None,
        "counterfactual_specificity_score": None,
        "counterfactual_valid_pseudo_seams": 0,
    }
    require(
        schema_matches(control, evidence_schema)
        and sample_candidate_semantics(control, protocol),
        "A C1-only comparison cannot record an accepted candidate",
    )
    counterfactual = copy.deepcopy(evidence)
    counterfactual["policy_extension_evidence"].update(
        {
            "counterfactual_status": "PASS",
            "counterfactual_image_score": 0.03,
            "counterfactual_specificity_score": 0.02,
            "counterfactual_valid_pseudo_seams": 8,
        }
    )
    require(
        schema_matches(counterfactual, evidence_schema)
        and sample_candidate_semantics(counterfactual, protocol),
        "A valid counterfactual ACCEPT cannot be recorded",
    )
    for sample, fields in (
        (evidence, ("image_sha256", "candidate_sha256", "model_sha256", "policy_sha256")),
        (runtime, ("image_sha256", "m0_array_sha256", "mask_after_array_sha256", "policy_sha256")),
    ):
        require(
            all(SHA256_RE.fullmatch(sample[field]) for field in fields),
            "Example contains an invalid SHA-256",
        )

    negative = copy.deepcopy(evidence)
    negative["image_sha256"] = "not-a-hash"
    require(not schema_matches(negative, evidence_schema), "Schema accepted a bad hash")
    negative = copy.deepcopy(evidence)
    negative["parent_instance_id"] = True
    require(not schema_matches(negative, evidence_schema), "Schema accepted a boolean instance ID")
    negative = copy.deepcopy(evidence)
    negative["c1"]["child_count"] = 3
    require(not schema_matches(negative, evidence_schema), "Schema accepted child-count/ID mismatch")
    negative = copy.deepcopy(evidence)
    negative["c1"]["new_ids_fresh"] = False
    require(not schema_matches(negative, evidence_schema), "Schema accepted a reused ID")
    negative = copy.deepcopy(evidence)
    negative["view_support"]["brightness_minus_5pct"] = False
    require(not schema_matches(negative, evidence_schema), "Schema accepted no photometric support")
    negative = copy.deepcopy(evidence)
    negative["score_missing"] = True
    require(not schema_matches(negative, evidence_schema), "Schema accepted missing ACCEPT score")
    negative = copy.deepcopy(evidence)
    negative["policy_extension_evidence"]["risk_budget_status"] = "FAIL"
    require(not schema_matches(negative, evidence_schema), "Schema accepted a failed FULL risk budget")
    negative = copy.deepcopy(evidence)
    negative["policy_extension_evidence"]["counterfactual_status"] = "FAIL"
    negative["policy_extension_evidence"]["counterfactual_image_score"] = 0.2
    negative["policy_extension_evidence"]["counterfactual_specificity_score"] = 0.1
    negative["policy_extension_evidence"]["counterfactual_valid_pseudo_seams"] = 8
    require(not schema_matches(negative, evidence_schema), "Schema accepted failed FULL counterfactual evidence")
    negative = copy.deepcopy(evidence)
    negative["policy_extension_evidence"]["risk_budget_used_before"] = 0.49
    require(not sample_candidate_semantics(negative, protocol), "Semantic audit accepted an exceeded image risk budget")
    negative = copy.deepcopy(counterfactual)
    negative["policy_extension_evidence"]["counterfactual_image_score"] = 0
    require(not sample_candidate_semantics(negative, protocol), "Semantic audit accepted a nonpositive counterfactual image score")
    negative = copy.deepcopy(evidence)
    negative["actual_harm"] = False
    require(not schema_matches(negative, evidence_schema), "Schema accepted a truth label")
    negative = copy.deepcopy(no_m0)
    negative["mask_fallback_written"] = True
    require(not schema_matches(negative, runtime_schema), "Schema accepted a made-up fallback")
    negative = copy.deepcopy(runtime)
    negative["m0_array_sha256"] = "bad"
    require(not schema_matches(negative, runtime_schema), "Runtime Schema accepted a bad hash")
    negative = copy.deepcopy(runtime)
    negative["mask_after_array_sha256"] = "5" * 64
    require(not sample_runtime_semantics(negative), "Semantic audit accepted unequal fallback hashes")

    try:
        from jsonschema import Draft202012Validator
    except ImportError:
        return "builtin_draft2020_subset"
    for schema, sample, name in samples + [
        (evidence_schema, control, "C1-only comparison"),
        (evidence_schema, counterfactual, "counterfactual FULL"),
    ]:
        Draft202012Validator.check_schema(schema)
        errors = list(Draft202012Validator(schema).iter_errors(sample))
        require(not errors, f"Full JSON Schema validation failed for {name}: {errors[0] if errors else ''}")
    return "builtin_and_jsonschema_draft2020"


def check_documents() -> tuple[int, int, int]:
    markdown_files = [ROOT / name for name in REQUIRED_FILES if name.endswith(".md")]
    link_count = 0
    cited_dois: set[str] = set()
    for markdown_file in markdown_files:
        content = markdown_file.read_text(encoding="utf-8")
        require(content.strip() != "", f"Empty document: {markdown_file.name}")
        cited_dois.update(
            doi.lower().rstrip(".,")
            for doi in re.findall(r"https://doi.org/(10\.[^\s)]+)", content, re.IGNORECASE)
        )
        for target in re.findall(r"\]\(([^)]+)\)", content):
            if target.startswith(("https://", "http://", "mailto:")):
                continue
            path = target.split("#", 1)[0]
            if path:
                link_count += 1
                require(
                    (markdown_file.parent / path).exists(),
                    f"Broken link in {markdown_file.name}: {target}",
                )
    bibliography = (ROOT / "references.bib").read_text(encoding="utf-8")
    keys = re.findall(r"^@\w+\{([^,]+),", bibliography, re.MULTILINE)
    require(len(keys) == len(set(keys)), "Bibliography has duplicate citation keys")
    dois = re.findall(r"^\s*doi\s*=\s*\{([^}]+)\}", bibliography, re.MULTILINE)
    require(len(dois) >= 15 and len(dois) == len(set(dois)), "Bibliography has missing or duplicate DOI entries")
    missing_dois = cited_dois - {doi.lower() for doi in dois}
    require(not missing_dois, f"Cited DOIs missing from bibliography: {sorted(missing_dois)}")
    return len(markdown_files), link_count, len(dois)


def main() -> None:
    check_checksum_manifest()
    protocol = read_json("protocol.json")
    task_data = read_json("tasks.json")
    check_protocol(protocol, task_data)
    task_count = check_tasks(task_data)
    schema_engine = check_schemas(protocol)
    document_count, link_count, doi_count = check_documents()
    print(
        json.dumps(
            {
                "status": "PACKAGE_CONTRACT_VALID",
                "documents": document_count,
                "local_links_checked": link_count,
                "tasks": task_count,
                "doi_entries": doi_count,
                "schema_engine": schema_engine,
                "experiments_run": False,
            },
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
