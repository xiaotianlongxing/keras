# 实验 SOP：粘连细胞核的风险感知局部纠错

此 SOP 供 WorkBuddy＋Kimi K3 自主执行。`nrr` 是执行 Agent **第一阶段要在研究项目中实现**的命令行入口；当前文档包尚无 `nrr` 可执行程序。每个阶段须先生成规定证据再继续，所有命令以实际可运行的 Python 模块实现并由 Agent 回填到 `runs/latest/commands.txt`。`<PROJECT>` 表示用户研究机器上的隔离项目目录；仓库内工作时可用 `research/nuclei-risk-repair`，不得修改生产服务代码。

## 0. 单次启动与能力预检

从 [`START_HERE.txt`](START_HERE.txt) 启动。WorkBuddy 首先检查文件读写、终端、Python、GPU、可用空间、网络、Kimi K3 连接、长任务恢复、浏览器下载能力；只把**能力状态**写入日志，绝不写 API 密钥或会话令牌。以下是应支持的最终接口，须先实现 `preflight` 和 `doctor`：

```bash
python -m nrr preflight --protocol protocol.json --output runs/preflight.json
python -m nrr doctor --protocol protocol.json --output runs/doctor.json
```

预检须实际创建临时文件、调用 `torch.cuda.is_available()`、打印设备名与显存、进行一轮前向/反向和 AMP 测试，并在 5060 Ti 上测速。核对磁盘至少有 60GB 空闲，训练峰值显存预留 2GB，GPU/CPU 内存溢出可被进程捕获。若环境未装 CUDA 版 PyTorch，先依据 PyTorch 官方页面为该驱动选择兼容版本，再重测；不能把 GPU 失败后的 CPU 训练当成满足 3 小时约束。若 WorkBuddy 缺少终端或 Kimi K3 当前无访问能力，记录 `BLOCKED_CAPABILITY`，列出具体欠缺能力及可恢复步骤；不得伪造运行状态。

初次计时采用 256×256、batch 8、20 次热身＋200 次更新的真实数据或合成同形数据；记录每步中位耗时、数据加载耗时、完整验证耗时。所有后续参数由该结果推算，再做 10 分钟小训练核对损失可下降。显存溢出时按 batch `8→4→2`、梯度累积补齐有效 batch；仍失败时通道 `24/48/96/192→16/32/64/128`，并为更改生成新版配置 ID。

## 1. 数据获取和谱系清单

1. 从 [NuInsSeg Zenodo](https://doi.org/10.5281/zenodo.10518968)下载图像、实例掩膜、歧义区域掩膜和数据说明；从 [MoNuSeg 官方页](https://monuseg.grand-challenge.org/Data/)及 [CoNSeP 论文关联资源](https://doi.org/10.1016/j.media.2019.101563)获取外测数据。CoNSeP 官方来源若需无法完成的登录或下载，最多重试 3 次并记录 HTTP/权限证据；在**任何外测图像或指标进入开发进程前**可改用 [CryoNuSeg 论文提供的官方项目入口](https://doi.org/10.1016/j.compbiomed.2021.104349) 作为第二外测，记录切换原因并锁定新的 `seal.json`。若下载入口变动，通过论文 DOI 和出版方数据可用性说明追踪；将最终 URL、版本、许可和引用写进 `data/source_manifest.json`。对单个入口最多自动重试 3 次，指数退避；不能用未经来源核实的镜像替代。
2. 每个原始文件保存 SHA-256、大小、尺寸、颜色顺序、bit depth、图像 ID、来源、可得的切片/患者/组织 ID。生成感知哈希候选重复清单；精确重复自动去重，近重复由算法生成可视化对照并锁定统一组。外部数据与训练来源如有同一原图或近重复，外测列表排除并在报告中列出数量。
3. 生成 `D_fit/D_dev/D_cal` 三个 NuInsSeg 人组织互斥清单，比例目标 60/20/20，按可核查的最高来源组整体分配；原图、增强和切块跟随同组。若仅有器官信息可用，用 `species+organ` 作为保守组键，并在报告中说明这是一种**器官组隔离**，不可宣称患者级独立。划分代码和 seed=17 在预览任何模型结果前固定。NuInsSeg 鼠组织单列 `D_mouse`；MoNuSeg 与锁定的 CoNSeP 或 CryoNuSeg 记为 `D_external` 并锁写保护。
4. 人工歧义掩膜可在 `D_fit` 用于监督忽略，在 `D_dev` 用于理解失败；`D_cal` 的歧义掩膜只能在策略冻结后供封存评价器作事后分析。其他外测集若未提供同等标注，不开展“人工歧义区”分层。所有用于训练的图像生成缩略图清单，随机审阅 20 个图块的 RGB/实例标签对齐、0 背景、整数实例 ID 和歧义标签形状。

目标接口及输出：

```bash
python -m nrr data fetch --protocol protocol.json --out data/source_manifest.json
python -m nrr data audit --manifest data/source_manifest.json --out reports/data_audit.json
python -m nrr data split --manifest data/source_manifest.json --seed 17 --out data/splits.json
python -m nrr data seal --manifest data/source_manifest.json --splits data/splits.json --out data/seal.json --fit-out data/fit_split.json --dev-out data/dev_split.json --images-dir data/
```

`splits.json` 只保存原图 ID、来源组与分组归属；`fit_split.json` 只含 `D_fit` 图像/真值路径，`dev_split.json` 只含 `D_dev` 图像/真值路径。`dev_images.json`、`cal_images.json` 与 `external_images.json` 均**只含图像路径和 ID**。`seal.json` 保存清单哈希、校准/外测真值的独立映射、各来源计数、分组层级和只读评价授权规则。监督训练入口只能接收 `fit_split.json`；开发调参与评估可以接收 `dev_split.json`；封存推理入口只接收图像清单、原预测和冻结模型。对任意 train/infer 入口传入 `seal.json`、`D_cal`/外测真值路径或完整 `source_manifest.json` 应立即拒绝并留审计日志。封存评价器与训练/推理进程分别运行。

## 2. 评价器先行

实现 PQ（实例匹配 IoU>0.5）、AJI、原图计数 MAE、局部配对损失、候选误伤标签、歧义区敏感性评价与原图级指标。输入为预测实例 ID 图和真值 ID 图；测试形状、实例 ID、背景、8 连通定义及忽略区处理完全相同。对空图、单实例、接触实例、标签 ID 跳号、纯假阳性、全拒绝等做手算或小数组核验。核对 NuInsSeg/HoVer-Net 公开指标实现的关键样例，禁止因为修正内部评价器而只重算本方法。

在训练前由 Kimi 完成 `reports/novelty_precheck.md`：检索 2024—2026 年核实例分割、局部编辑、选择性预测、无真值质量估计和风险控制，逐篇记录 DOI、全文或摘要访问级别、是否已评估“保留/修改”动作差值、是否有候选级伤害与同覆盖率对照。全文不可得时标 `ABSTRACT_ONLY`，不得据此断言前人没有相关方法。T17 再更新投稿时的全文与期刊核查；若先期检索发现关键近邻已覆盖本课题主张，须在任何封存外测前修订设计版本并重新评估可行性。

大批候选的 `dPQ` 标签不要逐候选重复做全图密集实例匹配：先缓存 `M0` 与真值的稀疏交并计数，只更新被分裂父实例涉及的行/列，再得到**与全图重算完全相同**的 `dPQ`。在 20 个随机候选、接触实例与一对多重叠手算例上逐项比对两种路径；若不一致，停止风险标签生成并回退到正确的慢实现。主指标固定为 MoNuSeg 语境的**原版 AJI**，AJI+ 只能另列次要指标；使用的公开参考代码来源、版本与手算用例须在 T04 写入 `metrics_audit.md`，不得混用两种名称。

```bash
python -m nrr metrics selfcheck --output reports/metrics_selfcheck.json
python -m nrr metrics audit --split data/fit_split.json --n-images 20 --output reports/metrics_audit.md
```

门槛：全部算例通过；20 个抽审图块中的实例数量与掩膜可视化一致；`reports/novelty_precheck.md` 已保存。任何指标定义变更重新生成 `protocol_version`，并重跑所有基线和方法。

## 3. 冻结轻量基线

采用 4 层轻量 U-Net，预测前景概率和归一化实例内距离图；在预测前景内做确定性 marker watershed，得到 `M0`。第一版输入 256×256，原始图按网格推理并在裁块边界用重叠和统一合并规则复原；如 NuInsSeg 已是固定图块，则保持原尺寸路径，不额外构造一个不同协议。训练增强仅为染色、轻度几何和噪声；参数与随机种子入配置。

为训练风险模型产生**非本图拟合的错误样本**：在 `D_fit` 的最高来源组上做 2 折。折 1 训练基线并预测折 2；折 2 训练基线并预测折 1。两份预测组成 `fit_oof_predictions`。最后在全部 `D_fit` 训练一个部署基线。三次训练及验证器训练的墙钟总和必须计入一个完整配置预算。不得用完整 `D_fit` 训练模型在自己的训练图上生成风险标签。

```bash
python -m nrr train baseline-oof --protocol protocol.json --split data/fit_split.json --output runs/latest/oof/ --output-time runs/latest/oof/time_budget.json
python -m nrr train baseline-final --protocol protocol.json --split data/fit_split.json --output runs/latest/baseline/
python -m nrr infer baseline --checkpoint runs/latest/baseline/model.pt --images data/dev_images.json --output runs/latest/dev_baseline/
```

训练日志记录实际 GPU 秒数、总墙钟、loss 曲线、验证 PQ、梯度/NaN、AMP 状态、峰值显存、权重 SHA-256。梯度训练与早停**只看 `D_fit` 内部训练折**；`D_dev` 真值只由独立开发评价/校准入口读取，外测结果不能决定训练步数。策略冻结前只缓存固定基线在 `D_dev` 的无真值预测；外部图像的首次模型推理也应在冻结后统一运行并留存访问日志，避免外部图像进入开发决策。

## 4. 候选生成与上界试验

对每个 `M0` 原始实例，只在以下两类情形生成候选：归一化距离图出现至少 2 个局部峰，或原始实例面积高于 `D_fit` 训练实例面积的第 90 百分位。阈值基于 `D_fit` 训练常数，不用本图真值。用 3 个平滑尺度产生至多 3 个**不同**的分水岭实例划分（2 或 3 个子实例）；`watershed_line=False`，候选子实例并集必须精确等于原父实例。最小子实例面积为 `max(8 像素, 0.02 × 父实例面积)`；不规则核不因“非凸”直接判错。

候选集总是包括 `RETAIN`。对每个候选执行 C1 检查：背景、父实例外的像素和前景二值图全等；子实例数必须为 2 或 3，每个子实例非空且 8 连通；按子实例重心 `(y,x)`、面积、局部像素哈希排序，第一个沿用父 ID，其余从原图最大 ID 之后顺序分配，且不得与任何原有或已分配 ID 冲突；父对象每次最多编辑一次。`child_count`、`child_count_valid`、`new_ids_fresh` 等检查逐候选落盘。任何一项失败时不得再执行后续模型筛选，而是回退该候选并记录 `C1_FAIL`。计算 `candidate_sha256` 时先按上述顺序将父包围框内子块重标为 1..K（父外为 0），拼接图像 SHA-256 的 32 原始字节、父 ID 的 `uint64` 小端、半开包围框 `(y0,x0,y1,x1)` 四个 `uint64` 小端、规范化分区的行优先 `uint8` 字节，再求 SHA-256；候选哈希不依赖随机文件名或最终全局 ID。

`candidate_invariants_base.json` 与 `candidate_invariants.json` 分别报告生成总数、无效数、各失败原因和进入后续筛选的合法数；**进入风险模型的候选 C1 通过率必须为 100%**，不要求错误提案从未出现，也不从故障统计里删除它们。

在 `D_dev` 的**真值隔离评价器**中计算三种固定的可行候选诊断：①逐原图只取真实 `dPQ` 最大且为正的单次编辑；②逐原图只取真实 `dCount` 最小且为负的单次编辑；③按局部 `dL` 正收益逐父贪心组合，最多遵守实际编辑预算。每种都保留 `RETAIN`、稳定哈希平分规则，并报告自己的完整 PQ、AJI、计数和局部配对指标；不能把三种的最佳列拼成一套虚假的方法结果。只有**全部三种**都满足 `ΔPQ≤0.005` 且 `ΔCountMAE≥0` 时，基础候选才按 [预注册方案 D](07-innovation-options.md) 尝试一次双来源提名。PQ/计数结果只能称“可行 oracle 诊断”，不能称严格数学上界。oracle 只判断候选空间，不进入风险特征或最终推理。隔离评价器把诊断写入报告，并仅将全局布尔值 `enable_dual_source` 写入 `d_trigger.json`；候选器不得读取报告或真值。T08 总是用选定模式重新生成 `D_fit` OOF 与 `D_dev` 最终候选、重做 C1 审计和 oracle，风险模型只能读取最终目录。最终三种可行诊断若均未满足 `ΔPQ>0.005` 或 `ΔCountMAE<0`，执行 `STOP_NEGATIVE_RESULT`。

```bash
python -m nrr candidates build --protocol protocol.json --predictions runs/latest/oof/ --output runs/latest/fit_candidates_base/
python -m nrr candidates build --protocol protocol.json --predictions runs/latest/dev_baseline/ --output runs/latest/dev_candidates_base/
python -m nrr candidates audit --candidates runs/latest/fit_candidates_base/ runs/latest/dev_candidates_base/ --output reports/candidate_invariants_base.json
python -m nrr oracle diagnose --candidates runs/latest/dev_candidates_base/ --dev data/dev_split.json --output reports/oracle_base_dev.json --trigger-out runs/latest/d_trigger.json
python -m nrr candidates build --protocol protocol.json --predictions runs/latest/oof/ --mode-file runs/latest/d_trigger.json --output runs/latest/fit_candidates/
python -m nrr candidates build --protocol protocol.json --predictions runs/latest/dev_baseline/ --mode-file runs/latest/d_trigger.json --output runs/latest/dev_candidates/
python -m nrr candidates audit --candidates runs/latest/fit_candidates/ runs/latest/dev_candidates/ --output reports/candidate_invariants.json
python -m nrr oracle diagnose --candidates runs/latest/dev_candidates/ --dev data/dev_split.json --output reports/oracle_dev.json
```

## 5. 独立图像证据与风险学习

**图像关系验证器**对每个像素对读取两处 5×5 RGB 小窗及归一化的相对位移 `(dy,dx,distance)`，输入两层隐藏层的轻量 MLP，输出该像素对属于同一个真值核的 **[0,1] 未校准分数** `s_same`。输入不含候选子块面积、切界长度或候选生成器隐藏特征，因而训练配对可直接从训练折的 RGB 与真值采样。训练时同核/异核配对在位移距离层内平衡，歧义区像素对忽略；推理时跨界/内部配对也按位移距离层匹配并记录缺层比例。平衡采样会改变类先验，故不可把 `s_same` 称为部署概率。固定纹理/颜色/边界特征的逻辑回归另列简单参考。分裂候选的切界两侧应获得低“同核”分数，候选内部像素对应获得高“同核”分数。

两个小窗分别以像素对端点为中心，越界镜像填充；按行优先 RGB 顺序展平并除以 255，`dy/dx/distance` 除以 64 后拼到末尾，MLP 隐层宽度固定为 64、32，末层 sigmoid。几何版将两处 RGB 槽逐通道置为仅由 `D_fit` 计算的固定均值，其他输入、架构、更新数与配对清单相同；不能从测试图估计替代值。

默认用 64×64 的原始 RGB 切界裁块，以图像哈希和固定 seed 确定性抽取最多 16 个跨子块切界像素对、16 个子块内部像素对；两类配对按同一距离层 `(0,1]、(1,2]、(2,4]、(4,8]` 像素与位移类型匹配。若 `|dx|≥2|dy|` 为水平，若 `|dy|≥2|dx|` 为垂直，其余为对角；零位移不入样本。每类少于 4 个有效像素对就拒绝该候选。候选验证分数固定为 `[1 - mean(s_same_cross) + mean(s_same_within)] / 2`，范围为 0—1。训练配对和部署配对使用同一特征及匹配规则；小窗或裁块越界时镜像填充，不得用真值补足配对。该分数门槛须在 `D_dev` 确定，不把它当独立真值。

同一批 OOF 训练配对还要拟合**同架构、同更新数与同采样**的几何版 MLP：两处 RGB 小窗输入槽统一替换成 `D_fit` 固定通道均值，仅保留 `(dy,dx,distance)`；两个折模型及留出评分保存于 `runs/latest/verifier_oof/geometry_only/`，部署版按全部 `D_fit` 拟合并保存于 `runs/latest/verifier/geometry_only.pt`，纳入 `all_models.sha256`。它只用于 B 的机制诊断，不参与 24 项策略搜索。T11/T15 先按全部 C1 候选分别报告两版评分覆盖率，再在共同可评分候选上配对比较事后收益关联及交集覆盖；即使完整版本更好，也只能先称 RGB 输入提高了该代理关联，完整策略的增量仍以匹配覆盖率外测为准。

对候选器所在 `D_fit` 两折，验证器也只能使用另一折的数据训练并给留出折打分。**验证器的训练配对直接从该训练折的 RGB 与真值采样，不读取 `fit_candidates` 里由“被评分折”训练的基线生成的候选**，避免经候选分布间接泄漏被评分折标签。用交叉拟合候选和验证分数训练 CPU 风险模型：输入为父面积、峰距离与高度、周边局部密度、切界关系分数、训练分布偏离分数以及平滑尺度分歧；输出 `p_harm` 和局部预期收益 `g`。标签与公式来自 [`04-statistics.md`](04-statistics.md)。模型可为小型梯度提升树/正则逻辑回归；模型大小、训练时间和推理时间均记录。完整 `D_fit` 上再训练部署版验证器。

OOD 分数用 `D_fit` OOF 候选的五个无标注特征拟合稳健中心与 MAD 尺度：父面积对数、苏木精光密度均值/标准差、局部预测核密度、峰距/父核半径。某个尺度下不足两个距离峰时该尺度的峰距定为 0，并另记峰数，不用真值补峰；若所有尺度都无法生成合法分裂则仅保留原实例。按 [`protocol.json`](protocol.json) 对标准化残差取均方根，MAD 加固定 epsilon 防零；第 90/95/99 百分位候选阈值都从 `D_fit` 得到，`D_dev` 只负责在该网格中选一个阈值。外测只能套用冻结尺度和阈值，不能用外测分布重新归一化。

OOD 中的苏木精通道与 C 的反事实证据共用 [`07-innovation-options.md`](07-innovation-options.md) 指定的固定 `rgb2hed` 转换和锁定库版本；A/B/C 的特征提取均不得在外测图上拟合颜色矩阵或归一化常数。

风险标签由只接收 `fit_split.json`、最终 OOF 候选和 OOF 原预测的独立 `metrics label-fit` 进程生成。逐候选标签文件至少含图像/来源组 ID、候选哈希、对应 OOF 权重哈希、评价器哈希、`local_valid`、`dL`、`dL_utility`、`dPQ`、`dCount`、`harm`、`help`；`reports/label_audit.json` 记录缺失/冲突候选与来源组越界数，非零即阻断训练。`train risk` 只能从这个标签文件按图像 ID＋候选哈希连接目标，不得再打开真值文件。

风险概率在 `D_dev` 按原图组报告 Brier、可靠性图与分组伤害率；概率后校准的开发集评估用 2 折**来源组交叉拟合**，再用全部 `D_dev` 拟合部署校准器，防止把同数据拟合后的 Brier 误当独立性能。只在 `D_dev` 选门槛、确定 OOD 和稳定性阈值；这些选择后的开发集效果仍是模型选择结果，最终依据封存外测。按 [创新性增强方案](07-innovation-options.md) 把每图风险预算 A、切界负对照 B、留出像素反事实证据 C 放入 T11 的**同一个最多 24 项开发策略搜索预算**。B 的伪切界生成、随机种子与分层规则必须在首次 T11 计算前已写入 `protocol.json` 并冻结，不能看过负对照后修改。输出 `reports/innovation_dev.json` 和 `reports/negative_controls_dev.json`；C 只有过匹配覆盖及耗时门槛才进入主策略。若风险模型无法超过简单置信度对照，保留结果并转入 `STOP_NEGATIVE_RESULT` 或更窄的研究主张。对新数据未见的组织类型，OOD 分数升高应触发拒绝；具体阈值在 `D_dev` 固定。

```bash
python -m nrr train verifier-oof --protocol protocol.json --split data/fit_split.json --output runs/latest/verifier_oof/
python -m nrr metrics label-fit --protocol protocol.json --fit data/fit_split.json --candidates runs/latest/fit_candidates/ --predictions runs/latest/oof/ --output runs/latest/fit_candidate_labels.jsonl --audit reports/label_audit.json
python -m nrr train risk --protocol protocol.json --input runs/latest/fit_candidates/ --verifier runs/latest/verifier_oof/ --labels runs/latest/fit_candidate_labels.jsonl --output runs/latest/risk/
python -m nrr train verifier-final --protocol protocol.json --split data/fit_split.json --output runs/latest/verifier/
python -m nrr calibrate dev --protocol protocol.json --dev data/dev_split.json --output runs/latest/policy_core_dev.json
python -m nrr calibrate innovations --protocol protocol.json --dev data/dev_split.json --core-policy runs/latest/policy_core_dev.json --output-policy runs/latest/policy_dev.json --output-metrics runs/latest/metrics_dev.json --output reports/innovation_dev.json
python -m nrr metrics negative-controls --protocol protocol.json --policy runs/latest/policy_dev.json --output reports/negative_controls_dev.json
```

## 6. 推理时无标注的证据与回退

冻结策略在每张图只可读取 `X`、`M0`、部署验证器、风险模型和开发阶段冻结的阈值。先对**全部 C1 合法候选**计算基础图像关系分数、OOD、`p_harm` 和 `g`，缺分数者明确记 `score_missing` 并拒绝；这保留 H3 事后关联检验的完整分母。再按 `p_harm` 升序、`g` 降序、原父实例 ID 和候选哈希排序，选至多 `min(16,ceil(0.1×原实例数))` 个父实例进入扰动和编辑预算检查。对这些父实例的原始 RGB 局部图分别做水平翻转、90° 旋转和固定 ±5% 亮度扰动；**从变换后的 RGB 重新计算局部验证分数，并按候选器的真实输入重跑提案**。逆变换后以父实例内的分区 ARI≥0.90 匹配候选，验证分数仍达开发集冻结阈值才算该视图支持。亮度视图若使用仅从 `M0` 得到的 EDT，候选本身不随亮度变化，应在日志中说明它只检验 RGB 验证证据。四种视图至少两种支持，且**几何视图至少一种、亮度视图至少一种**，再满足 [`04-statistics.md`](04-statistics.md) 中其他 C2 条件才接受。测试时不读取 `Y` 或 `U`。

每个候选写入一条完整记录：运行种子、方法 ID、图像 ID/哈希、父实例 ID、候选哈希、子实例数与各 C1 布尔项、`g`、`p_harm`、验证器分数、各视图支持、OOD 分数、是否接受及拒绝原因、耗时、模型/阈值哈希。推理目录还须保存**全部 C1 合法候选（含被拒绝者）**的局部子实例分区：`candidate_manifest.jsonl` 每行列种子、图像 ID/哈希、父 ID、候选哈希、父包围框、`proposal_relpath` 和提案文件 SHA-256；`candidate_proposals/` 中保存对应压缩 RLE 或无损整数数组，不能只保存最后被接受的 `M*`。

同一种子的对照可复用同一提案池：清单以 `(seed,image_id,candidate_sha256)` 唯一，证据以 `(seed,method_id,image_id,candidate_sha256)` 唯一；每个需评估候选的证据均须连接到一条清单及一份提案，同一清单可被多个方法引用。`infer audit` 用 `M0` 和提案文件重建该候选，校验哈希、C1、清单与各方法证据的连接完整性。风险概率是估计，JSON 中不得出现 `actual_harm`；后者只能由隔离评价器在后处理文件中追加。这样封存评价器可直接复算每个候选的事后 `help/harm/dL_utility`，**不得为 H3 重新推理或重新提名候选**。

`evidence.jsonl` 的 `policy_extension_evidence` 记录 A 的每图预算状态、上限和该候选前已用的预计伤害数，以及 C 的状态、原始图像分数、伪切界特异性分数和有效伪切界数；未启用填 `NOT_ENABLED` 与 `null`，提前被其他门槛拒绝而未计算时填 `NOT_EVALUATED`。`FULL` 接受时，A/C 若启用必须各自为 `PASS`；预算是否越限、C 分数是否过冻结阈值由 `infer audit` 结合整个图的候选顺序和策略文件复算。其他对照允许 `g/p_harm/verifier/OOD/视图` 按其算法不计算而填 `null`，但所有 `ACCEPT` 都须满足 C1，审计器按冻结的 `method_id` 单独核对接受规则。B 的基础分数打乱方法固定记 `method_id=BASE_SCORE_SHUFFLE`：每个预测目录的 `score_shuffle_manifest.jsonl` 保存种子、数据集、候选键、分层、来源候选键、原分数、代入风险模型的分数及置换种子；空时也须建文件。审计器重算预冻结层内置换并与 `FULL` 原分数及打乱方法所用分数核对，不能只相信打乱后的结果表。

同一预测目录还须在**读取任何封存真值前**落盘 `mechanism_scores.jsonl`，每个 C1 合法候选一行，键为 `(seed,image_id,candidate_sha256)`。行内含数据集、父 ID、图像/政策哈希、主验证器与几何版验证器的模型哈希和基础分数、两版对每条伪切界的分数数组、伪切界分区哈希、有效条数及逐项缺失原因；数组可少于 8 条但须如实记缺失，C 启用时不足 8 条必须拒绝。`FULL` 的基础 `verifier_score` 必须与此文件的主分数一致。`infer audit` 从 RGB、冻结模型及提案重算抽样、两版分数和伪切界并核对键、覆盖率与文件哈希；封存评价器只读已审计的 `mechanism_scores.jsonl`，连接事后 `help/harm` 算 B/H3，绝不在评价器内补跑模型或生成伪切界。

几何版或 B 的伪切界诊断缺分数时，只记原因与覆盖率，不改变未启用 C 的 `FULL` 接受决策；若 C 已启用且伪切界不足，按 C 的规则拒绝该候选。主验证器的候选级缺分数导致该候选拒绝；模型级运行错误按整图 `ABSTAIN_RUNTIME` 回退。

运行错误单独逐行写入 `runtime_errors.jsonl`，遵循 `schemas/runtime-error.schema.json`。若已取得且校验了 `M0`，权重、阈值、显存或证据计算失败时整张图原子回退 `M*=M0`，`mask_before` 与 `mask_after` 逐元素全等，运行错误记 `ABSTAIN_RUNTIME`；若回退文件本身写入失败，改记 `FALLBACK_WRITE_FAILED` 并阻断评价。若图像读取或基线模型失败导致**尚无 `M0`**，只记 `PREDICTION_UNAVAILABLE`，不得虚构回退掩膜。运行错误里的数组哈希按 `uint32` 小端、先写 `(height,width)` 两个 `uint64` 小端、再写行优先 ID 数组字节计算；`infer audit` 仍须直接读取两个掩膜逐元素比较，不能只信哈希字符串。T12/T14/T15 的完整性门槛阻断任何缺掩膜或提案文件的评价，修复客观故障后对整批冻结方法重推。`evidence.jsonl` 只记录已构造且完成判定的候选；故障图不得留下部分 `ACCEPT` 记录或半成品提案目录。正常图输出 `mask_before`、`mask_after`、候选清单与提案、`evidence.jsonl` 及可视化。可视化不由人工修改，再由 C1 检查程序逐图验证并生成各 split 的 `reports/invariants_*.json`。

以下命令是 T13 冻结后的接口示例；T12 用 `policy_all_dev.json` 与 `data/dev_images.json` 执行等价检查，不得提前把 `data/external_images.json` 交给方法进程。`infer audit` 除验证 JSON Schema 外，还须读取本次策略文件，逐候选复核 C1、`child_count` 与实际子实例/`child_instance_ids` 数量相等、每个新 ID 对原图及本图先前编辑均未使用、编辑数量与面积预算。对 `FULL`，须从 RGB、提案和冻结模型重算四视图分区 ARI、验证分数及支持布尔值，再核对风险/收益/OOD 阈值、A 的逐图累计预计伤害、C 的 `E_image>0`、`E_specific>0`、开发阈值及 8 条伪切界；对其他 `method_id` 核对各自冻结规则，对 `BASE_SCORE_SHUFFLE` 还要重算置换。对 `ABSTAIN_RUNTIME` 比对两个规范化数组哈希并直接比较掩膜数组，核对运行错误及原图覆盖完整性。不能只靠 Schema 的字段类型或保存的支持布尔值判定 `ACCEPT` 合法。

```bash
python -m nrr infer correct --policy runs/latest/policy_frozen.json --images data/external_images.json --output runs/latest/external_predictions/
python -m nrr infer audit --policy runs/latest/policy_frozen.json --predictions runs/latest/external_predictions/ --output reports/invariants_external.json
```

## 7. 三种种子、对照、消融与算力账本（T12）

**这一步必须在策略冻结及任何封存测试真值访问之前完成。** 用种子 17 的 `D_dev` 结果按预注册规则选出主策略；`train replicate` 只接收 `fit_split.json`，核验并复用已完成的种子 17 权重，再按完全相同的模型结构和训练预算训练种子 29、43。随后由**独立的** `calibrate replicate-dev` 入口读取 `dev_split.json`，对每个种子用相同算法拟合概率后校准器并套用种子 17 已选定的数值接受阈值；不能为 29、43 单独搜索新阈值或选择最好种子。三套完整权重、阈值、代码和配置哈希都要列入 `all_models.sha256`。

`train replicate` 是只见 `D_fit` 的编排入口：种子 29/43 各自重跑两折基线 OOF、同一 `d_trigger.json` 选定的候选器、验证器 OOF、独立 `metrics label-fit` 子进程、风险模型和部署模型；种子 17 仅在训练配置与权重哈希一致时复用。每种子的 `replicate_models/<seed>/` 必须留 OOF 组排除表、候选/标签清单与标签审计、全部模型权重和单配置计时。`train replicate` 不得内嵌 `D_dev` 的评价或早停；`calibrate replicate-dev` 才能在开发评价进程里读取 `D_dev` 真值。这样 T12 的三种子模型不是只重新训练最后一个权重。

在 `D_dev` 上准备全部固定对照及消融，之后不再训练对照。清单为：`M0`、`ALL_CANDIDATES`、固定切界阈值、原模型距离峰置信度筛选、`VERIFIER_ONLY`、`RISK_ONLY`、`STABILITY_ONLY`、B 的固定种子打乱验证分数、逐候选风险阈值与每图风险预算的匹配覆盖对照，以及完整方法。`ALL_CANDIDATES` 只表示对每个可编辑父实例按固定 `q_split` 取**一个**分裂动作，仍遵守数量/面积上限；其他消融的同父动作选择与跨父排序都按 [`04-statistics.md`](04-statistics.md) 第 7 节固定，不能随意选有利动作。除 `M0` 外，各筛选对照复用同种子的候选与基础预测；`RISK_ONLY` 须去掉验证器特征后在 `D_fit` **重新训练 CPU 风险模型**，这是公平消融，成本计入配置；打乱验证分数只作破坏性机制对照。纯阈值消融复用冻结分数，不为它们另训模型。固定切界与原模型置信度的候选级公式、各自最多 24 个阈值、开发集选择规则见统计协议，与完整方法使用相同开发搜索机会。B 的伪切界规则和打乱种子在**首次 T11 计算前**固定，T13 将它们与全部对照阈值一并封存。若另加 StarDist/HoVer-Net 等外部权重参考，先披露权重来源和潜在外测重叠；其成绩另表，不混成同训练资源对照。`reports/ablations_dev.json` 和 C1 逐例检查必须先生成。

```bash
python -m nrr train replicate --protocol protocol.json --fit data/fit_split.json --mode-file runs/latest/d_trigger.json --base-policy runs/latest/policy_dev.json --seeds 17 29 43 --output runs/latest/replicate_models/ --output-time runs/latest/replicate_train_times.json
python -m nrr calibrate replicate-dev --protocol protocol.json --dev data/dev_split.json --models runs/latest/replicate_models/ --base-policy runs/latest/policy_dev.json --train-times runs/latest/replicate_train_times.json --output-policy runs/latest/policy_all_dev.json --output-hashes runs/latest/all_models.sha256 --output-time runs/latest/time_budget.json
python -m nrr infer correct --policy runs/latest/policy_all_dev.json --images data/dev_images.json --output runs/latest/dev_predictions/
python -m nrr infer audit --policy runs/latest/policy_all_dev.json --predictions runs/latest/dev_predictions/ --output reports/invariants_dev.json
python -m nrr evaluate dev --policy runs/latest/policy_all_dev.json --dev data/dev_split.json --predictions runs/latest/dev_predictions/ --output reports/ablations_dev.json
```

`runs/latest/time_budget.json` 按 `config_id` 和种子保存**每个完整配置的一条独立记录**，字段至少含 `oof_1_s/oof_2_s/base_final_s/verifier_oof_s/verifier_final_s/verifier_main_oof_s/verifier_geometry_oof_s/verifier_main_final_s/verifier_geometry_final_s/risk_s/validation_s/total_train_wall_s/total_config_wall_s/peak_vram_gb`，其中两个总验证器字段分别等于主版与几何版子字段之和，并有累计 GPU 小时汇总。**每配置总训练目标≤9,000 秒，整配置墙钟硬上限 10,200 秒**；两版验证器、候选伪样本生成和必要验证全部计时。达到上限时按预先记录的缩模/少步规则换配置 ID，保留旧结果，不隐去超时实验。无 GPU 的预处理和一次性下载另报墙钟。三个种子及额外结构对照的**累计 GPU 小时另报**，不误写成一个配置的时长。报告基础前向、完整纠错、每图候选数、拒绝原因比例和吞吐量；完整推理目标≤基础推理的 3 倍，超出也如实列出。

预检后对主版与几何版分别实测每步中位耗时、反算共同更新数，并给每阶段预留验证时间；首次配置的 150 分钟**规划上限**为：基线 OOF 两折合计 50 分钟、最终基线 25 分钟、主版＋几何版验证器 OOF 各两折合计 30 分钟、两版最终验证器合计 15 分钟、风险模型/候选/开发验证及 A/B/C 合计 30 分钟。若预计超过任一阶段上限，先按第 0 节缩模或减少更新数并更换配置 ID，再完整运行；不能训练到超时后只截取一段日志算“合规”。额外 20 分钟仅是配置启动、序列化等墙钟余量，不计为增加训练额度。上述是预算分配，**不是已测速度或效果**。

## 8. 冻结、校准审计和唯一外部测试（T13—T16）

在读取 `D_cal` 真值前，从 `policy_all_dev.json` 冻结**种子 17/29/43 及全部对照**的代码快照、基线/验证器/风险权重、概率后校准器、全部数值阈值、评价器版本、主结果表模板和 20 张人工核对记录，生成 `policy_frozen.json`。只对预指定的种子 17 主策略尝试 C3 审核；若也要对其他种子声称 C3，需在查看校准结果前声明多重比较数并按 [`04-statistics.md`](04-statistics.md) 分配显著性水平。校准审计对完整策略运行一次，输出 C3 是否建立及原因；不因审计失败而用同一 `D_cal` 改阈值。

然后在一次外部测试任务内，对 MoNuSeg、预锁定的 CoNSeP 或 CryoNuSeg、NuInsSeg 鼠组织的**全部冻结种子与对照**运行统一推理，再由隔离评价进程读取真值。`reports/h3_association.json` 必须只从 `method_id=FULL` 的证据单列种子 17 在 MoNuSeg 的预指定主 AUROC、评分覆盖率、来源组数、区间与状态；种子 29/43 和第二外测集单列复现结果，不能看后挑种子。MoNuSeg 官方训练/测试子集分别成表，跨数据集整体另成表，不能称官方排行榜结果。NuInsSeg 人组织 `D_cal` 可在冻结后按统计协议的 5 像素切界距离与父实例拒绝率评估人工歧义区域；此 H4 分层仅作探索性报告，其他数据无同等标注时不填。T16 只汇总 T15 已生成的逐图结果，**不得在外测后训练新种子、增删对照、切换外测来源或修改策略**。

```bash
python -m nrr freeze --protocol protocol.json --run runs/latest/ --dev-policy runs/latest/policy_all_dev.json --output runs/latest/policy_frozen.json
python -m nrr infer correct --policy runs/latest/policy_frozen.json --images data/cal_images.json --output runs/latest/cal_predictions/
python -m nrr infer audit --policy runs/latest/policy_frozen.json --predictions runs/latest/cal_predictions/ --output reports/invariants_cal.json
python -m nrr evaluate calibration --policy runs/latest/policy_frozen.json --seal data/seal.json --predictions runs/latest/cal_predictions/ --invariants reports/invariants_cal.json --output reports/calibration.json
python -m nrr infer correct --policy runs/latest/policy_frozen.json --images data/external_images.json --output runs/latest/external_predictions/
python -m nrr infer audit --policy runs/latest/policy_frozen.json --predictions runs/latest/external_predictions/ --output reports/invariants_external.json
python -m nrr evaluate external --policy runs/latest/policy_frozen.json --seal data/seal.json --predictions runs/latest/external_predictions/ --invariants reports/invariants_external.json --h3-output reports/h3_association.json --output reports/external_results.json
python -m nrr evaluate summarize --results reports/external_results.json --output reports/results.md
python -m nrr evaluate aggregate --results reports/external_results.json --h3 reports/h3_association.json --all-seeds-output reports/all_seeds.json --comparison reports/comparison.md
```

T14/T15 的顺序固定为**只读图像推理并原子落盘 → 独立 C1/完整性审计 → 封存评价器只读 `--predictions` 与真值**。评价器不得内部重新推理、替换预测或修改冻结阈值；预测目录哈希与审计报告哈希不一致即拒绝评估。`evaluate summarize` 属于 T15 的报告导出；`evaluate aggregate` 属于 T16，**只读 T15 的 JSON 并写三种种子和对照汇总**，不能再访问真值或运行模型。`external_results.json` 只在一次性封存评估任务中产生，须含全部冻结种子、对照和原图。若实现问题使输出损坏，允许**修复可客观复现的程序错误**，但须保存旧代码和旧结果、列出修复差异并对全部方法重算；任何方法参数改变都要换新外部数据，不能利用旧测试集选择新版方法。

## 9. 自动质控与失败分支

T17 只从 T15/T16 的封存 JSON、预先保存的文献核查记录和运行日志生成图表与论文初稿；期刊分区若无单位认可的权威版本，CSV 中写 `UNVERIFIED`。T18 对全文每一条数字和比较句核验来源，按预注册门槛写 `decision.json`。`paper draft` 可以调用已配置的 Kimi K3，但稿件数字只能由数据脚本导出；缺外测结果时生成失败分析初稿，不伪造正结果。最终交给用户审阅，不自动投稿。

```bash
python -m nrr paper journal-screen --protocol protocol.json --references references.bib --output reports/journal_screen.csv
python -m nrr paper draft --protocol protocol.json --results reports/external_results.json --all-seeds reports/all_seeds.json --comparison reports/comparison.md --h3 reports/h3_association.json --journals reports/journal_screen.csv --output paper/manuscript.md --ledger paper/claim_ledger.csv --figures paper/figures/
python -m nrr paper audit --manuscript paper/manuscript.md --ledger paper/claim_ledger.csv --results reports/external_results.json --output reports/evidence_audit.md
python -m nrr paper decide --audit reports/evidence_audit.md --results reports/external_results.json --h3 reports/h3_association.json --output runs/latest/decision.json
```

若 T08 或 T11 在外测前触发 `STOP_NEGATIVE_RESULT`，**不执行依赖 T16 的正常 T17/T18**；在 `state.json` 将后续任务标 `SKIPPED_EARLY_STOP`，从已有开发报告生成题目、方法、失败证据和局限的负结果初稿，明确“未做外测”。此早停终支不要求不存在的 `external_results.json`：

```bash
python -m nrr paper negative-draft --state state.json --run runs/latest/ --available-reports reports/ --output paper/manuscript.md --ledger paper/claim_ledger.csv --review reports/negative_result_review.md
python -m nrr paper audit --manuscript paper/manuscript.md --ledger paper/claim_ledger.csv --state state.json --output reports/evidence_audit.md
python -m nrr paper decide --audit reports/evidence_audit.md --state state.json --output runs/latest/decision.json
```

若 T00—T04 发生无法自行解除的能力/数据硬阻断，生成 `blocked.json`、`runs/latest/decision.json` 与 `reports/blocked_review.md`，列已完成证据、欠缺外部条件及可恢复步骤；不生成伪论文。若测试封存被提前破坏，改为 `TEST_LEAKED`，列文件访问证据并终止该测试集。具体终支及产物见 `tasks.json.terminal_branches`。

| 问题 | 自动动作 | 状态与证据 |
| --- | --- | --- |
| 数据 URL 临时失败 | 最多三次重试，校验哈希与文件大小；仅换论文指向的官方入口 | `DATA_BLOCKED` 加 URL/时间/HTTP 状态 |
| 来源 ID 不足 | 回退到最保守可核查组；降低独立性结论级别 | `GROUP_PROXY_USED` 加分组表 |
| 训练 OOM/NaN | 缩 batch、开启累计或缩通道；产生新版配置并完整重跑 | `CONFIG_REVISED` 加两版计时 |
| 候选 C1 失败 | 该候选拒绝并保留掩膜；保存失败输入 | `C1_FAIL`, 若系统性失败则停止评估 |
| 校准误伤率过高或组数不足 | 输出 C3 未建立；保持冻结策略，真实结果继续评估 | `C3_NOT_ESTABLISHED` 加上界/样本数 |
| 外测退化 | 生成负结果分析，不解封测试后调参 | `STOP_NEGATIVE_RESULT` |
| Agent 会话中断 | 读取 `state.json`、校验前序产物哈希，从第一项未完成任务恢复 | `RECOVERED` 加恢复点 |

首次执行过程最多需要用户完成其平台本来要求的登录、数据网站注册或访问授权；Agent 必须在 `blocked.json` 中明确指出缺失项。一般方法选择、阈值候选和失败分析由本 SOP 自行解决。Agent 不得使用“自证有效”替代外测真值审计。
