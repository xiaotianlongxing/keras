# WorkBuddy＋Kimi K3 自主研究执行规范

## 角色、能力与边界

WorkBuddy 负责任务编排、终端/文件操作、调用 Kimi K3、运行训练和整理证据；Kimi K3 负责代码生成、分析日志、查核文献及论文初稿。执行前先确认两者在用户机器上确实具备文件、终端、联网、长任务恢复和模型调用能力。工具名称与调用格式以用户安装版本为准，本包不假设存在未核实的 WorkBuddy CLI。缺少能力时输出可读的阻断文件，不能把“已设计自动化”写成“实验已完成”。

在研究项目根目录实现独立 Python 包 `nrr/`、`tests/`、`data/`、`runs/`、`reports/`、`paper/`。若本包仍在 `/workspace/ams-py-argus/docs/research/nuclei-risk-repair/`，先原样复制到该仓库的 `research/nuclei-risk-repair/` 后再执行；不得修改现有业务服务 `src/`。用户工作区的 AGENTS.md 不允许主动 Git 写操作：保存源码快照与 SHA-256 清单即可，**不得 `git add/commit/checkout/push`**。不要向外部消息工具发通知、自动投稿或公开数据。登录与 API 凭证使用现有安全存储或进程环境，日志只记录“可用/不可用”，不记录值。

## 启动时须读的文件

顺序：`README.md` → `01-proposal.md` → `04-statistics.md` → `02-sop.md` → `07-innovation-options.md` → `08-literature-journal-screen.md` → `protocol.json` → `tasks.json` → `05-paper-protocol.md` → `06-task-plan.md`。首条执行指令见 `START_HERE.txt`。不能只读开题摘要就自行改变主终点、测试划分或统计单位。

## 持久状态机

`state.json` 是唯一进度账本。每项任务完成要原子写入（先写临时文件再替换），保留上次成功结果和产物 SHA-256；会话恢复时从首个未完成或哈希不匹配任务继续。状态只能按下列顺序前进：

`runs/latest/` 是**真实的当前运行目录**，不是符号链接；`state.json.active_run_id` 保存唯一运行 ID，`tasks.json` 的 `runs/latest/...` 路径按字面验收。配置失败需要完整重跑时，先把旧 `runs/latest/` 原子移入 `runs/history/<active_run_id>/`；同步把当前 `reports/` 中除 `history/` 外的文件快照到只写一次的 `reports/history/<active_run_id>/`，记录逐文件哈希，验证快照后才允许新配置覆盖根目录报告。随后创建新的 `runs/latest/` 并更新状态；历史哈希与失败日志保留。报告 JSON 必须含实际 `run_id/config_id/protocol_version`，新运行不能仅凭旧报告文件存在就判任务完成；可复用的静态数据/文献报告须核对数据及协议哈希并在 `state.json` 记录继承来源。SOP 中所有命令均写当前目录，日志里的 `run_id` 仍使用唯一 ID，不能填字符串 `latest`。这使 Windows 上没有符号链接权限时也能恢复。

`state.json` 中单文件产物记原始字节 SHA-256；目录产物递归列出常规文件，拒绝符号链接与未完成的临时文件，按相对目录根的 POSIX 路径 UTF-8 字节排序。每项写一行 `<文件 SHA-256>  <相对路径>\n`，再对此规范化 UTF-8 清单求 SHA-256 作为目录根哈希；空目录不算任务完成。任务完成后不得向该已封存目录追加文件，恢复时重算根哈希；不匹配则保留旧目录和原因，从该任务起重做，不能只改 `state.json` 里的哈希。

```text
NEW → PREFLIGHT_OK → DATA_SEALED → METRICS_VERIFIED
    → BASELINE_READY → CANDIDATES_READY → VERIFIER_READY
    → DEV_POLICY_SELECTED → POLICY_FROZEN → CAL_AUDITED
    → EXTERNAL_EVALUATED → PAPER_DRAFTED → EVIDENCE_AUDITED
```

`BLOCKED_CAPABILITY`、`DATA_BLOCKED`、`CONFIG_REVISED`、`STOP_NEGATIVE_RESULT` 是明确终止或恢复分支。当前状态、尝试次数、下一动作和阻断理由必须写入 `state.json` 和 `runs/latest/status.md`。同一可恢复错误最多自动重试 3 次；固定代码错误先定位和修复，再重跑对应任务，禁止无限自循环。所有候选训练过程只占用一张 GPU，进程锁 `gpu.lock`；不允许多个 Agent 并发争抢 16GB 显存。

正常 T17/T18 依赖已完成 T16；`tasks.json.terminal_branches` 另规定 T08/T11 科研早停、早期外部能力阻断和封存泄漏。早停时把后续正常任务记 `SKIPPED_EARLY_STOP`，生成只含已有开发证据的负结果初稿与 `decision.json`，不得向不存在的外测结果取数。能力阻断只生成 `blocked.json`、阻断分析和决策；封存泄漏保留访问证据并废止该测试。任何终支不得把未运行任务标 `COMPLETED`。

## Autoresearch 搜索空间

实验 Agent 在 `D_dev` 可搜索的范围仅为 `protocol.json` 的 `dev_search` 与 `innovation_extensions`。第一轮最多 12 个组合；如果有初步收益，再加最多 12 个精细组合，**A 风险预算和 C 留出像素证据的组合也计入同一个 24 项上限**，B 负对照固定执行而非另开无穷搜索。B 的伪切界与打乱规则在首次 T11 计算前已经由 `protocol.json` 固定。固定切界和原模型置信度两个对照各有最多 24 个预定分位阈值，按相同编辑组覆盖率规则选择；见 `04-statistics.md`。每个实验生成独立 `config_id`、来源哈希和结果。训练结构初版固定为同一个轻量基线；方法组件分别开启/关闭做消融，不能在看到外部测试后新增组件。

选择主策略的**预注册排序**：

1. 全部 C1 精确不变量通过，完整单配置训练时间≤150分钟、墙钟≤170分钟。
2. `D_dev` 上至少有 10 张被编辑原图，接受候选数/可提名父实例数≥0.05；若不达标，结论为覆盖不足，不把零误伤作为“成功”。
3. 在满足前两项的策略中，要求 `ΔCountMAE≤0`，再按 `ΔPQ` 最大排序；PQ 相同时选估计组级误伤率较低者，再选耗时较短者。若策略包含 C 反事实证据，还须先满足 `07-innovation-options.md` 的匹配覆盖率、PQ 增量和耗时门槛。
4. 若全部策略均不满足，冻结 `RETAIN_ALL` 作为安全基线，输出 `STOP_NEGATIVE_RESULT`；禁止降低已经注册的成功条件去追求正结果。

上述排序只用 `D_dev`。`D_cal` 只审计冻结政策并作预注册的人工歧义区事后分析，不用于模型、阈值或事后挑选主张。随机种子为 17、29、43；主要方法选择先在 17 上完成，29/43 为稳定性复现实验，不挑最好种子。**三个种子与全部固定对照必须在 T12 训练或准备完毕，T13 一起冻结，T15 一次运行全部外测，T16 仅汇总**。若三个种子收敛差异较大，论文据实报告。

## 可复现输出契约

正常完成 T18 的 `runs/latest` 至少包含：`config.json`、`env.json`、`data_hashes.json`、`commands.txt`、`stdout.log`、`stderr.log`、`time_budget.json`、`metrics_dev.json`、`all_models.sha256`、`decision.json`。每个预测目录按图保存原始与修正掩膜，并有 `evidence.jsonl`、`candidate_manifest.jsonl`、`candidate_proposals/` 和 `runtime_errors.jsonl`；三种 JSONL 为空时也须存在以便审计。候选证据逐行符合 `schemas/evidence.schema.json`，只在候选 ID/哈希已知且完整判定时产生；每条合法候选证据须连接到对应清单与提案文件，同一提案可供同种子的多个方法引用，供封存评价器事后复算被拒绝编辑的结果。运行错误逐行符合 `schemas/runtime-error.schema.json`。若已有经校验的 `M0`，错误可记 `ABSTAIN_RUNTIME` 并落盘逐元素相同的回退掩膜；若尚无 `M0`，必须记 `PREDICTION_UNAVAILABLE`、`mask_fallback_written=false`，并阻断完整性审计。外测还须有 `reports/invariants_external.json`、`reports/external_results.json` 和 `reports/h3_association.json`。

每个预测目录还须建立 `score_shuffle_manifest.jsonl` 和 `mechanism_scores.jsonl`：前者记录 B 的固定基础分数置换谱系，未运行打乱对照时为空；后者在解封真值前保存全部合法候选的 RGB/几何版与伪切界分数或缺失原因，供 H3/B 只读关联。诊断分数缺失不改变未启用 C 的 `FULL` 决策。所有方法的 `ACCEPT` 记录均满足 C1；只有 `method_id=FULL` 要求完整 C2/A/C 字段。其他方法按自身冻结策略审核，不得拿完整方法的风险与扰动门槛否决固定阈值或消融对照。上述目录均是未来执行 Agent 的产物，本交付包当前只有 Schema 与示例。

每次改动都回答四个问题并写入 `runs/latest/research_note.md`：原假设是什么、改变了什么、验证证据是什么、下一步依据是什么。只有 `metrics_dev.json` 与对应完整日志存在时，Kimi 才能写“D_dev 提升”；只有外部报告生成时才写“外部提升”。没有依据时使用“待验证”，并自动回到可执行任务。

## 数据封存实现要求

WorkBuddy 应把预测进程和评价进程设计成两个不同入口。`nrr infer` 的参数只能传图像清单与冻结策略/模型文件；T14/T15 的 `nrr evaluate` **只读已经落盘且通过 C1/完整性审计的 `--predictions`** 和封存真值，内部不得再运行模型。训练/风险模型的导入路径不得包含 `data/external_masks` 与 `data/cal_masks`；写一个运行时拦截测试，调用推理入口时如果传入真值路径应立刻失败。工作目录权限不足以在同一用户进程中形成绝对安全隔离，因此还要保留文件访问清单和哈希审计。Agent 必须遵守封存规则；测试标签被提前访问就把这套测试作废，在 `decision.json` 中标为 `TEST_LEAKED`。

## Agent 故障与决策表

| 观察 | 自主动作 | 最终记录 |
| --- | --- | --- |
| 依赖、CUDA 或下载错误 | 查官方兼容说明、在锁定环境中修复并重跑预检 | 原错误、修复后的实测日志 |
| 基线极差 | 核对掩膜、颜色、损失和重建；只用 `D_fit/D_dev` 调参 | 改动前后配置和同一 DEV 指标 |
| C1 失败 | 退回原掩膜，修复实现；此前结果全部标记无效 | 触发图哈希、最小复现例 |
| 无可用候选 | 输出候选上界为零，停止改进路线 | `STOP_NEGATIVE_RESULT` |
| 风险模型劣于简单门槛 | 保留负证据，完成简化方法和论文限制分析 | 消融表与样本量 |
| C3 条件不足 | 保持 C2 实证表述，附独立组数与原因 | `C3_NOT_ESTABLISHED` |
| 外测下降 | 完整展示所有测试结果与失败图，写负结果初稿 | `STOP_NEGATIVE_RESULT` |
| WorkBuddy 会话中断 | 核验 `state.json` 与 SHA-256，从首个未完成任务恢复 | `RECOVERED` 与断点 |

若同一硬阻断持续三次且无法通过已有权限与工具解决，生成 `blocked.json`，只列**一次**真正需要用户处理的外部条件；其余任务继续完成。用户允许的无标注设定已明确，不需要重复询问。

## 论文 Agent 的约束

论文只从 `reports/results.md`、机器生成 CSV/JSON、通过核对的文献元数据和可追溯实验日志取数字。先建逐句 `claim_ledger.csv`：`claim_id,claim_text,evidence_path,evidence_key,dataset,analysis_unit,limitations`。每个数字、指标和“优于”句子都必须能找到记录。不得把抄来的参考论文成绩与本实验成绩混成公平比较；不得为显示创新而杜撰“首次”或“达到临床应用”。按 `08-literature-journal-screen.md` 留存期刊分区/SCIE 证据，拿不到官方证据时写 `UNVERIFIED`。若统计审核未达 C3，全文不写“分布无关保证/置信保证”；若只有无标注代理证据，不写“证明单例正确”。

WorkBuddy 可自行完成**代码、实验、统计、图表和论文初稿**。论文能否投稿、是否符合单位期刊分区及任何对外发布由用户在阅读产物后决定；自动化本身无法保证正结果或录用。
